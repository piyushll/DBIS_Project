import os
import secrets
from typing import Any, Dict, List, Optional, Union
from pydantic import BaseSettings, PostgresDsn, validator, AnyHttpUrl


class Settings(BaseSettings):
    # Project name
    PROJECT_NAME: str = "Conference Management System"
    API_V1_STR: str = "/api"
    
    # SECURITY
    SECRET_KEY: str = secrets.token_urlsafe(32)
    ALGORITHM: str = "HS256"
    # 60 minutes * 24 hours * 7 days = 7 days
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24 * 7
    
    # Database connection
    POSTGRES_SERVER: str = "localhost"
    POSTGRES_USER: str = "postgres"
    POSTGRES_PASSWORD: str = "postgres"
    POSTGRES_DB: str = "conference_management"
    POSTGRES_PORT: str = "5432"
    DATABASE_URI: Optional[PostgresDsn] = None

    @validator("DATABASE_URI", pre=True)
    def assemble_db_connection(cls, v: Optional[str], values: Dict[str, Any]) -> Any:
        if isinstance(v, str):
            return v
        return PostgresDsn.build(
            scheme="postgresql",
            user=values.get("POSTGRES_USER"),
            password=values.get("POSTGRES_PASSWORD"),
            host=values.get("POSTGRES_SERVER"),
            port=values.get("POSTGRES_PORT"),
            path=f"/{values.get('POSTGRES_DB') or ''}",
        )
    
    # CORS settings
    BACKEND_CORS_ORIGINS: List[AnyHttpUrl] = []

    @validator("BACKEND_CORS_ORIGINS", pre=True)
    def assemble_cors_origins(cls, v: Union[str, List[str]]) -> List[str]:
        if isinstance(v, str) and not v.startswith("["):
            return [i.strip() for i in v.split(",")]
        elif isinstance(v, (list, str)):
            return v
        raise ValueError(v)
    
    # Data and file storage
    BASE_DIR: str = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    UPLOAD_DIR: str = os.path.join(BASE_DIR, "uploads")
    DBLP_DATA_DIR: str = os.path.join(BASE_DIR, "data/dblp")
    DBLP_XML_FILENAME: str = "dblp.xml"
    
    # Conflict detection parameters
    CONFLICT_COAUTHORSHIP_YEARS: int = 5  # Check coauthorship within last 5 years
    CONFLICT_MIN_PAPERS_THRESHOLD: int = 3  # More than 3 papers is a strong conflict
    CONFLICT_ORGANIZATION_YEARS: int = 2  # Check same organization within last 2 years
    
    # Reviewer assignment parameters
    MIN_REVIEWERS_PER_PAPER: int = 3
    MAX_REVIEWERS_PER_PAPER: int = 5
    MAX_PAPERS_PER_REVIEWER: int = 5
    ENABLE_DIVERSITY_REQUIREMENTS: bool = True
    MIN_ORGANIZATION_DIVERSITY: int = 2  # At least 2 different organizations
    MIN_COUNTRY_DIVERSITY: int = 2  # At least 2 different countries
    
    # Spark configuration for DBLP processing
    SPARK_MASTER: str = "local[*]"
    SPARK_APP_NAME: str = "DBLP Processor"
    SPARK_EXECUTOR_MEMORY: str = "4g"
    
    class Config:
        case_sensitive = True
        env_file = ".env"


# Create settings instance
settings = Settings()

# Ensure upload directory exists
os.makedirs(settings.UPLOAD_DIR, exist_ok=True)
os.makedirs(os.path.join(settings.UPLOAD_DIR, "papers"), exist_ok=True)
os.makedirs(settings.DBLP_DATA_DIR, exist_ok=True)
