"""
Core package for the Conference Management System.

This package contains core functionality that powers the entire application,
including configuration management and security utilities.
"""

__version__ = "0.1.0"

# Import key components that should be accessible directly from app.core
from app.core.config import settings
from app.core.security import (
    create_access_token,
    get_password_hash,
    verify_password,
    get_current_user,
    get_current_active_user
)

# Export these items as part of the public API of the core package
__all__ = [
    "settings",
    "create_access_token",
    "get_password_hash",
    "verify_password",
    "get_current_user",
    "get_current_active_user",
]
