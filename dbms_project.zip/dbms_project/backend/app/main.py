from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.api import auth, papers, reviewers, conflicts
from app.core.config import settings
from app.db.session import init_db

# Create the FastAPI app
app = FastAPI(
    title=settings.PROJECT_NAME,
    description="Conference Management System with CoI detection and reviewer diversity",
    version="0.1.0",
)

# Configure CORS
if settings.BACKEND_CORS_ORIGINS:
    app.add_middleware(
        CORSMiddleware,
        allow_origins=[str(origin) for origin in settings.BACKEND_CORS_ORIGINS],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

# Create tables on startup
@app.on_event("startup")
async def startup_event():
    init_db()

# Include routers
app.include_router(auth.router, prefix=settings.API_V1_STR, tags=["auth"])
app.include_router(papers.router, prefix=settings.API_V1_STR, tags=["papers"])
app.include_router(reviewers.router, prefix=settings.API_V1_STR, tags=["reviewers"])
app.include_router(conflicts.router, prefix=settings.API_V1_STR, tags=["conflicts"])

# Root endpoint
@app.get("/")
async def root():
    return {
        "message": "Conference Management System API",
        "documentation": "/docs"
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
