"""
Services package for the Conference Management System.

This package contains core service components that implement the business logic
for the conference management system, including:

- DBLP dataset parsing and processing
- Conflict of interest detection algorithms
- Reviewer assignment optimization with diversity constraints
"""

__version__ = "0.1.0"

# Import key components that should be accessible directly from app.services
from app.services.dblp_parser import DBLPParser
from app.services.conflict_detector import ConflictDetector
from app.services.reviewer_assigner import ReviewerAssigner

# Export these items as part of the public API of the services package
__all__ = [
    "DBLPParser",
    "ConflictDetector",
    "ReviewerAssigner",
]
