import logging
from datetime import datetime, timedelta
from typing import List, Dict, Set, Tuple, Optional
from sqlalchemy.orm import Session
from sqlalchemy import and_, or_, func

from app.db.models import Author, Paper, Reviewer, ConflictRecord, coauthorship
from app.core.config import settings

logger = logging.getLogger(__name__)

class ConflictDetector:
    """
    Service for detecting conflicts of interest between authors and reviewers.
    
    This class implements algorithms to detect three types of conflicts:
    1. Coauthorship conflicts - authors who have published together within a time window
    2. Organizational conflicts - authors from the same institution
    3. Location conflicts - authors from the same geographical location
    """
    
    def __init__(self, db: Session):
        """Initialize the conflict detector with a database session."""
        self.db = db
        self.coauthorship_years = settings.CONFLICT_COAUTHORSHIP_YEARS
        self.org_years = settings.CONFLICT_ORGANIZATION_YEARS
        self.min_papers_threshold = settings.CONFLICT_MIN_PAPERS_THRESHOLD
    
    def detect_all_conflicts(self, author_id: int, reviewer_id: int) -> Dict[str, bool]:
        """
        Detect all types of conflicts between an author and a potential reviewer.
        
        Args:
            author_id: ID of the paper author
            reviewer_id: ID of the potential reviewer
            
        Returns:
            Dictionary with conflict types and boolean status
        """
        # Get author and reviewer author profiles
        author = self.db.query(Author).filter(Author.id == author_id).first()
        reviewer_author = self.db.query(Author).filter(Author.user_id == 
                          self.db.query(Reviewer).filter(Reviewer.id == reviewer_id).first().user_id).first()
        
        if not author or not reviewer_author:
            logger.warning(f"Author ID {author_id} or reviewer author profile not found")
            return {"has_conflict": False}
        
        # Detect different conflict types
        coauthorship_conflict = self._detect_coauthorship_conflict(author.id, reviewer_author.id)
        organization_conflict = self._detect_organization_conflict(author, reviewer_author)
        location_conflict = self._detect_location_conflict(author, reviewer_author)
        
        has_conflict = coauthorship_conflict or organization_conflict or location_conflict
        
        # Record conflict if found
        if has_conflict:
            self._record_conflict(author.id, reviewer_author.id, 
                                  coauthorship_conflict, organization_conflict, location_conflict)
        
        return {
            "has_conflict": has_conflict,
            "coauthorship_conflict": coauthorship_conflict,
            "organization_conflict": organization_conflict,
            "location_conflict": location_conflict
        }
    
    def _detect_coauthorship_conflict(self, author_id: int, reviewer_author_id: int) -> bool:
        """
        Detect if two authors have co-authored papers within the configured time window.
        
        This method checks:
        1. Direct coauthorship through the coauthorship association table
        2. Recent collaborations within the configured year threshold
        """
        # Check pre-computed coauthorship relationship
        coauthor_record = self.db.query(coauthorship).filter(
            or_(
                and_(coauthorship.c.author1_id == author_id, 
                     coauthorship.c.author2_id == reviewer_author_id),
                and_(coauthorship.c.author1_id == reviewer_author_id, 
                     coauthorship.c.author2_id == author_id)
            )
        ).first()
        
        if coauthor_record:
            # Check if collaboration is within the time window
            cutoff_date = datetime.now() - timedelta(days=365 * self.coauthorship_years)
            if coauthor_record.last_collaboration and coauthor_record.last_collaboration >= cutoff_date:
                return True
            
            # Check if collaboration frequency exceeds threshold
            if coauthor_record.paper_count >= self.min_papers_threshold:
                return True
        
        # Fallback to direct paper check if coauthorship record not found
        cutoff_date = datetime.now() - timedelta(days=365 * self.coauthorship_years)
        
        # Find papers where both are authors within time window
        common_papers = self.db.query(Paper).filter(
            Paper.authors.any(Author.id == author_id),
            Paper.authors.any(Author.id == reviewer_author_id),
            Paper.publication_date >= cutoff_date
        ).count()
        
        return common_papers > 0
    
    def _detect_organization_conflict(self, author: Author, reviewer_author: Author) -> bool:
        """
        Detect if author and reviewer are from the same organization.
        
        Checks both current and past affiliations within configured time window.
        """
        # Check current affiliation
        if author.affiliation and reviewer_author.affiliation:
            if author.affiliation.lower() == reviewer_author.affiliation.lower():
                return True
        
        # Check previous affiliations if stored (assuming JSON format)
        # This would require parsing the JSON-formatted previous_affiliations field
        # The implementation would depend on the exact format used
        
        return False
    
    def _detect_location_conflict(self, author: Author, reviewer_author: Author) -> bool:
        """
        Detect if author and reviewer are from the same geographical location.
        
        Currently checks for same city, could be extended to check for proximity.
        """
        if author.city and reviewer_author.city:
            if author.city.lower() == reviewer_author.city.lower():
                return True
        
        return False
    
    def _record_conflict(self, author_id: int, reviewer_author_id: int, 
                         coauthorship: bool, organization: bool, location: bool) -> None:
        """Record detected conflicts in the database for future reference."""
        if coauthorship:
            self._add_conflict_record(author_id, reviewer_author_id, "coauthorship", 
                                     f"Coauthored papers within {self.coauthorship_years} years")
        
        if organization:
            self._add_conflict_record(author_id, reviewer_author_id, "organization", 
                                     "Same organization affiliation")
        
        if location:
            self._add_conflict_record(author_id, reviewer_author_id, "location", 
                                     "Same city location")
    
    def _add_conflict_record(self, author1_id: int, author2_id: int, 
                            conflict_type: str, details: str) -> None:
        """Add a conflict record to the database."""
        conflict = ConflictRecord(
            author1_id=author1_id,
            author2_id=author2_id,
            conflict_type=conflict_type,
            details=details
        )
        self.db.add(conflict)
        self.db.commit()
    
    def get_eligible_reviewers(self, paper_id: int) -> Tuple[List[Dict], List[Dict]]:
        """
        Get lists of eligible and ineligible reviewers for a paper.
        
        Args:
            paper_id: ID of the paper
            
        Returns:
            Tuple containing (eligible_reviewers, ineligible_reviewers)
        """
        paper = self.db.query(Paper).filter(Paper.id == paper_id).first()
        if not paper:
            logger.error(f"Paper ID {paper_id} not found")
            return [], []
        
        # Get all active reviewers
        reviewers = self.db.query(Reviewer).filter(Reviewer.availability == True).all()
        
        eligible = []
        ineligible = []
        
        for reviewer in reviewers:
            reviewer_author = self.db.query(Author).filter(
                Author.user_id == reviewer.user_id
            ).first()
            
            if not reviewer_author:
                continue
            
            # Check if reviewer is one of the paper authors
            is_author = reviewer_author.id in [a.id for a in paper.authors]
            if is_author:
                ineligible.append({
                    "id": reviewer.id,
                    "name": reviewer.user.username,
                    "reason": "Author of the paper"
                })
                continue
            
            # Check for conflicts with any paper author
            has_conflict = False
            conflict_reasons = []
            
            for author in paper.authors:
                conflicts = self.detect_all_conflicts(author.id, reviewer.id)
                if conflicts["has_conflict"]:
                    has_conflict = True
                    if conflicts["coauthorship_conflict"]:
                        conflict_reasons.append(f"Coauthorship with {author.name}")
                    if conflicts["organization_conflict"]:
                        conflict_reasons.append(f"Same organization as {author.name}")
                    if conflicts["location_conflict"]:
                        conflict_reasons.append(f"Same location as {author.name}")
            
            if has_conflict:
                ineligible.append({
                    "id": reviewer.id,
                    "name": reviewer.user.username,
                    "reason": ", ".join(conflict_reasons)
                })
            else:
                eligible.append({
                    "id": reviewer.id,
                    "name": reviewer.user.username,
                    "affiliation": reviewer_author.affiliation,
                    "country": reviewer_author.country,
                    "city": reviewer_author.city,
                    "expertise": reviewer.expertise_keywords
                })
        
        return eligible, ineligible
