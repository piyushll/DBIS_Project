import logging
from typing import List, Dict, Set, Tuple, Optional
import numpy as np
from sqlalchemy.orm import Session
from sqlalchemy import func

from app.db.models import Paper, Reviewer, Author, ReviewerAssignment, User
from app.services.conflict_detector import ConflictDetector
from app.core.config import settings

logger = logging.getLogger(__name__)

class ReviewerAssigner:
    """
    Service for optimizing reviewer assignments to papers.
    
    This class implements algorithms to assign reviewers to papers while:
    1. Avoiding conflicts of interest
    2. Matching reviewer expertise to paper topics
    3. Ensuring diversity of assigned reviewers
    4. Balancing workload among reviewers
    """
    
    def __init__(self, db: Session, conflict_years: int = None):
        """Initialize the reviewer assigner with a database session."""
        self.db = db
        self.conflict_detector = ConflictDetector(db)
        self.conflict_years = conflict_years or settings.CONFLICT_COAUTHORSHIP_YEARS
    
    def assign_reviewers(
        self, 
        paper_id: int, 
        num_reviewers: int = 3,
        ensure_diversity: bool = True
    ) -> List[int]:
        """
        Assign reviewers to a paper, considering expertise, conflicts and diversity.
        
        Args:
            paper_id: ID of the paper needing reviewers
            num_reviewers: Number of reviewers to assign (default: 3)
            ensure_diversity: Whether to enforce diversity constraints (default: True)
            
        Returns:
            List of assigned reviewer IDs
        """
        paper = self.db.query(Paper).filter(Paper.id == paper_id).first()
        if not paper:
            logger.error(f"Paper ID {paper_id} not found")
            return []
        
        # Get all available reviewers
        available_reviewers = self.db.query(Reviewer).filter(
            Reviewer.availability == True
        ).all()
        
        if not available_reviewers:
            logger.error("No available reviewers found")
            return []
        
        # Filter out reviewers who already have too many assignments
        max_papers_per_reviewer = settings.MAX_PAPERS_PER_REVIEWER
        reviewer_loads = self._get_reviewer_loads()
        eligible_reviewers = [
            r for r in available_reviewers 
            if reviewer_loads.get(r.id, 0) < max_papers_per_reviewer
        ]
        
        if not eligible_reviewers:
            logger.error("No eligible reviewers with capacity found")
            return []
        
        # Get paper authors
        paper_authors = paper.authors
        
        # Calculate affinity scores for all eligible reviewers
        reviewer_scores = []
        for reviewer in eligible_reviewers:
            # Get reviewer's author profile
            reviewer_author = self.db.query(Author).filter(
                Author.user_id == reviewer.user_id
            ).first()
            
            if not reviewer_author:
                continue
            
            # Check for conflicts
            has_conflict = False
            for author in paper_authors:
                conflicts = self.conflict_detector.detect_all_conflicts(
                    author.id, reviewer.id
                )
                if conflicts["has_conflict"]:
                    has_conflict = True
                    break
            
            if has_conflict:
                continue
            
            # Calculate expertise affinity score
            affinity_score = self._calculate_affinity(paper, reviewer)
            
            # Get reviewer's metadata for diversity consideration
            reviewer_metadata = self._get_reviewer_metadata(reviewer, reviewer_author)
            
            reviewer_scores.append({
                "reviewer_id": reviewer.id,
                "affinity_score": affinity_score,
                "metadata": reviewer_metadata,
                "current_load": reviewer_loads.get(reviewer.id, 0)
            })
        
        # If no eligible reviewers without conflicts, return empty list
        if not reviewer_scores:
            logger.error(f"No eligible reviewers without conflicts for paper {paper_id}")
            return []
        
        # Choose reviewers based on affinity and diversity
        if ensure_diversity:
            selected_reviewers = self._select_diverse_reviewers(
                reviewer_scores, num_reviewers
            )
        else:
            # Just select based on affinity score if diversity not required
            selected_reviewers = sorted(
                reviewer_scores, 
                key=lambda x: x["affinity_score"], 
                reverse=True
            )[:num_reviewers]
        
        return [r["reviewer_id"] for r in selected_reviewers]
    
    def _calculate_affinity(self, paper: Paper, reviewer: Reviewer) -> float:
        """
        Calculate affinity score between paper and reviewer based on expertise matching.
        
        Higher score means better match.
        """
        # Split paper keywords and reviewer expertise into sets of terms
        paper_keywords = set(paper.keywords.lower().split(',')) if paper.keywords else set()
        reviewer_expertise = set(reviewer.expertise_keywords.lower().split(',')) if reviewer.expertise_keywords else set()
        
        # Calculate keyword overlap
        common_keywords = paper_keywords.intersection(reviewer_expertise)
        
        # Keyword match score (0-1)
        keyword_score = len(common_keywords) / max(len(paper_keywords), 1) if paper_keywords else 0
        
        return keyword_score
    
    def _get_reviewer_metadata(self, reviewer: Reviewer, reviewer_author: Author) -> Dict:
        """Get reviewer metadata for diversity consideration."""
        user = self.db.query(User).filter(User.id == reviewer.user_id).first()
        
        return {
            "organization": reviewer_author.affiliation,
            "country": reviewer_author.country,
            "city": reviewer_author.city,
            "seniority": self._calculate_seniority(reviewer_author),
        }
    
    def _calculate_seniority(self, author: Author) -> int:
        """
        Calculate seniority level based on author's publication history.
        
        Returns a value 1-3 representing junior, mid-career, or senior.
        """
        paper_count = len(author.papers)
        
        if paper_count < 5:
            return 1  # Junior
        elif paper_count < 20:
            return 2  # Mid-career
        else:
            return 3  # Senior
    
    def _get_reviewer_loads(self) -> Dict[int, int]:
        """Get current assignment load for all reviewers."""
        reviewer_loads = {}
        
        # Query current assignments
        assignments = self.db.query(
            ReviewerAssignment.reviewer_id,
            func.count(ReviewerAssignment.id).label('assignment_count')
        ).group_by(ReviewerAssignment.reviewer_id).all()
        
        for reviewer_id, count in assignments:
            reviewer_loads[reviewer_id] = count
        
        return reviewer_loads
    
    def _select_diverse_reviewers(
        self, 
        reviewer_scores: List[Dict], 
        num_reviewers: int
    ) -> List[Dict]:
        """
        Select reviewers to maximize both expertise match and diversity.
        
        Uses a greedy algorithm with diversity penalty/bonus.
        """
        if len(reviewer_scores) <= num_reviewers:
            return reviewer_scores
        
        # Sort by affinity score initially
        sorted_reviewers = sorted(
            reviewer_scores, 
            key=lambda x: x["affinity_score"], 
            reverse=True
        )
        
        selected = [sorted_reviewers[0]]  # Start with best matching reviewer
        remaining = sorted_reviewers[1:]
        
        # Greedy selection with diversity consideration
        while len(selected) < num_reviewers and remaining:
            # Calculate diversity scores for remaining reviewers relative to already selected
            for candidate in remaining:
                diversity_score = self._calculate_diversity_score(selected, candidate)
                # Combine affinity and diversity with weighting
                candidate["combined_score"] = (
                    0.7 * candidate["affinity_score"] + 
                    0.3 * diversity_score
                )
            
            # Select reviewer with best combined score
            remaining.sort(key=lambda x: x["combined_score"], reverse=True)
            selected.append(remaining[0])
            remaining = remaining[1:]
        
        return selected
    
    def _calculate_diversity_score(
        self, 
        selected_reviewers: List[Dict], 
        candidate: Dict
    ) -> float:
        """
        Calculate how diverse a candidate reviewer is compared to already selected reviewers.
        
        Higher score means more diverse (different from existing reviewers).
        """
        diversity_score = 0.0
        
        # Get candidate metadata
        candidate_meta = candidate["metadata"]
        
        # Check organization diversity
        orgs = set(r["metadata"]["organization"] for r in selected_reviewers 
                  if r["metadata"]["organization"])
        if candidate_meta["organization"] and candidate_meta["organization"] not in orgs:
            diversity_score += 0.25
        
        # Check geographical diversity
        countries = set(r["metadata"]["country"] for r in selected_reviewers 
                      if r["metadata"]["country"])
        if candidate_meta["country"] and candidate_meta["country"] not in countries:
            diversity_score += 0.25
        
        # Check seniority diversity (1=junior, 2=mid, 3=senior)
        seniorities = set(r["metadata"]["seniority"] for r in selected_reviewers)
        if candidate_meta["seniority"] not in seniorities:
            diversity_score += 0.25
        
        return diversity_score
    
    def batch_assign_reviewers(
        self, 
        paper_ids: List[int],
        reviewers_per_paper: int = 3,
        ensure_diversity: bool = True,
        max_papers_per_reviewer: Optional[int] = None
    ) -> Dict:
        """
        Assign reviewers to multiple papers, optimizing global assignment.
        
        Args:
            paper_ids: List of paper IDs to assign reviewers to
            reviewers_per_paper: Number of reviewers per paper
            ensure_diversity: Whether to enforce diversity constraints
            max_papers_per_reviewer: Override default max papers per reviewer
            
        Returns:
            Dictionary with assignment results
        """
        if max_papers_per_reviewer is None:
            max_papers_per_reviewer = settings.MAX_PAPERS_PER_REVIEWER
        
        results = {
            "assignments": {},
            "failed_papers": [],
            "summary": {
                "total_papers": len(paper_ids),
                "successful_papers": 0,
                "failed_papers": 0
            }
        }
        
        # Get all papers and reviewers to avoid repeated queries
        papers = self.db.query(Paper).filter(Paper.id.in_(paper_ids)).all()
        paper_dict = {p.id: p for p in papers}
        
        if len(papers) != len(paper_ids):
            missing_ids = set(paper_ids) - set(paper_dict.keys())
            logger.error(f"Some papers not found: {missing_ids}")
            results["failed_papers"].extend([
                {"paper_id": pid, "reason": "Paper not found"} 
                for pid in missing_ids
            ])
        
        # Get all available reviewers
        available_reviewers = self.db.query(Reviewer).filter(
            Reviewer.availability == True
        ).all()
        
        if not available_reviewers:
            logger.error("No available reviewers found")
            results["failed_papers"].extend([
                {"paper_id": pid, "reason": "No available reviewers"} 
                for pid in paper_ids
            ])
            results["summary"]["failed_papers"] = len(paper_ids)
            return results
        
        # Get current reviewer loads
        reviewer_loads = self._get_reviewer_loads()
        
        # Initialize reviewer capacities 
        reviewer_capacities = {
            r.id: max_papers_per_reviewer - reviewer_loads.get(r.id, 0)
            for r in available_reviewers
        }
        
        # For each paper, calculate affinity scores with non-conflicted reviewers
        paper_reviewer_affinity = {}
        
        for paper_id in paper_ids:
            if paper_id not in paper_dict:
                continue
                
            paper = paper_dict[paper_id]
            paper_authors = paper.authors
            
            # Calculate affinity and check conflicts for all reviewers
            reviewer_scores = []
            
            for reviewer in available_reviewers:
                # Skip if reviewer is at capacity
                if reviewer_capacities[reviewer.id] <= 0:
                    continue
                    
                # Get reviewer's author profile
                reviewer_author = self.db.query(Author).filter(
                    Author.user_id == reviewer.user_id
                ).first()
                
                if not reviewer_author:
                    continue
                
                # Check for conflicts
                has_conflict = False
                for author in paper_authors:
                    conflicts = self.conflict_detector.detect_all_conflicts(
                        author.id, reviewer.id
                    )
                    if conflicts["has_conflict"]:
                        has_conflict = True
                        break
                
                if has_conflict:
                    continue
                
                # Calculate expertise affinity score
                affinity_score = self._calculate_affinity(paper, reviewer)
                
                # Get reviewer's metadata for diversity consideration
                reviewer_metadata = self._get_reviewer_metadata(reviewer, reviewer_author)
                
                reviewer_scores.append({
                    "reviewer_id": reviewer.id,
                    "affinity_score": affinity_score,
                    "metadata": reviewer_metadata,
                })
            
            paper_reviewer_affinity[paper_id] = reviewer_scores
        
        # Sort papers by number of available reviewers (assign most constrained papers first)
        papers_by_constraints = sorted(
            [(pid, len(scores)) for pid, scores in paper_reviewer_affinity.items()],
            key=lambda x: x[1]
        )
        
        # Assign reviewers to papers
        for paper_id, num_available in papers_by_constraints:
            if num_available < reviewers_per_paper:
                # Not enough non-conflicted reviewers
                results["failed_papers"].append({
                    "paper_id": paper_id,
                    "reason": f"Only {num_available} non-conflicted reviewers available"
                })
                results["summary"]["failed_papers"] += 1
                continue
            
            reviewer_scores = paper_reviewer_affinity[paper_id]
            
            # Select reviewers considering diversity if requested
            if ensure_diversity:
                selected_reviewers = self._select_diverse_reviewers(
                    reviewer_scores, reviewers_per_paper
                )
            else:
                # Just select based on affinity score
                selected_reviewers = sorted(
                    reviewer_scores, 
                    key=lambda x: x["affinity_score"], 
                    reverse=True
                )[:reviewers_per_paper]
            
            selected_ids = [r["reviewer_id"] for r in selected_reviewers]
            
            # Update reviewer capacities
            for rid in selected_ids:
                reviewer_capacities[rid] -= 1
            
            # Record assignment
            results["assignments"][paper_id] = selected_ids
            results["summary"]["successful_papers"] += 1
        
        return results
