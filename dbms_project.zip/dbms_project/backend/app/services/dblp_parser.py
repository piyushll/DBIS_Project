import logging
import os
import gzip
import shutil
import urllib.request
from datetime import datetime, timedelta
from typing import List, Dict, Optional, Any
import xml.sax
from sqlalchemy.orm import Session
from sqlalchemy import and_, or_

from app.db.models import Author, Paper, coauthorship, DBLPUpdateLog
from app.core.config import settings

logger = logging.getLogger(__name__)

class DBLPHandler(xml.sax.ContentHandler):
    """SAX handler for parsing DBLP XML data efficiently."""
    
    def __init__(self):
        super().__init__()
        self.current_element = None
        self.current_data = ""
        self.current_paper = {}
        self.current_authors = []
        self.paper_count = 0
        self.author_count = 0
        
        # Define valid publication types and data fields to extract
        self.publication_types = {
            'article', 'inproceedings', 'proceedings', 'book', 
            'incollection', 'phdthesis', 'mastersthesis'
        }
        self.data_fields = {
            'title', 'booktitle', 'year', 'journal', 'volume', 
            'number', 'pages', 'publisher', 'author', 'ee'
        }
        
    def startElement(self, tag, attributes):
        """Handle opening XML tags."""
        self.current_element = tag
        
        # If starting a new publication record
        if tag in self.publication_types:
            self.current_paper = {
                'type': tag,
                'key': attributes.get('key', ''),
                'mdate': attributes.get('mdate', ''),
                'authors': []
            }
            self.current_authors = []
    
    def characters(self, content):
        """Handle tag content."""
        if self.current_element in self.data_fields:
            self.current_data += content
    
    def endElement(self, tag):
        """Handle closing XML tags."""
        if tag in self.publication_types:
            # Store author information
            self.current_paper['authors'] = self.current_authors
            self.process_publication(self.current_paper)
            self.paper_count += 1
            
            # Clear for next record
            self.current_paper = {}
            self.current_authors = []
        
        elif self.current_element == 'author' and self.current_data.strip():
            self.current_authors.append(self.current_data.strip())
            self.author_count += 1
        
        elif self.current_element in self.data_fields and self.current_data.strip():
            self.current_paper[self.current_element] = self.current_data.strip()
        
        # Reset for next element
        self.current_element = None
        self.current_data = ""
    
    def process_publication(self, publication):
        """Process a publication record (implemented by subclasses)."""
        pass


class DBLPParser:
    """
    Parser for the DBLP XML dataset to extract coauthorship information.
    
    This class handles downloading, extracting, and parsing the DBLP dataset,
    focusing on extracting author relationships for conflict-of-interest detection.
    """
    
    def __init__(self, db: Session):
        """Initialize the DBLP parser with a database session."""
        self.db = db
        self.dblp_path = settings.DBLP_DATA_DIR
        self.xml_path = os.path.join(self.dblp_path, settings.DBLP_XML_FILENAME)
        self.dtd_path = os.path.join(self.dblp_path, "dblp.dtd")
        
        # Ensure the directory exists
        os.makedirs(self.dblp_path, exist_ok=True)
    
    def download_latest_dump(self) -> bool:
        """
        Download the latest DBLP XML dump and DTD file.
        
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            # URLs for DBLP data
            xml_url = "https://dblp.org/xml/dblp.xml.gz"
            dtd_url = "https://dblp.org/xml/dblp.dtd"
            
            logger.info("Downloading DBLP XML dump from %s...", xml_url)
            xml_gz_path = f"{self.xml_path}.gz"
            urllib.request.urlretrieve(xml_url, xml_gz_path)
            
            logger.info("Downloading DBLP DTD from %s...", dtd_url)
            urllib.request.urlretrieve(dtd_url, self.dtd_path)
            
            logger.info("Extracting DBLP XML...")
            with gzip.open(xml_gz_path, 'rb') as f_in:
                with open(self.xml_path, 'wb') as f_out:
                    shutil.copyfileobj(f_in, f_out)
            
            # Clean up compressed file
            os.remove(xml_gz_path)
            
            logger.info("DBLP dataset downloaded successfully")
            return True
            
        except Exception as e:
            logger.error("Failed to download DBLP dataset: %s", str(e))
            return False
    
    def parse_and_store(self, limit: Optional[int] = None) -> Dict[str, Any]:
        """
        Parse the DBLP XML file and store relevant information in the database.
        
        Args:
            limit: Optional limit on number of publications to process (for testing)
            
        Returns:
            Dictionary with statistics about processed data
        """
        if not os.path.exists(self.xml_path):
            logger.error("DBLP XML file not found at %s", self.xml_path)
            return {"error": "XML file not found"}
        
        logger.info("Starting to parse DBLP XML file: %s", self.xml_path)
        start_time = datetime.now()
        
        # Create a custom handler that will store data in the database
        handler = DBLPDatabaseHandler(self.db, limit)
        
        try:
            # Create SAX parser
            parser = xml.sax.make_parser()
            parser.setContentHandler(handler)
            
            # Parse the file
            parser.parse(self.xml_path)
            
            # Extract coauthorship relationships
            self.extract_coauthorship_network()
            
            end_time = datetime.now()
            duration = (end_time - start_time).total_seconds()
            
            # Log statistics
            stats = {
                "papers_processed": handler.paper_count,
                "authors_processed": handler.author_count,
                "new_authors_created": handler.new_authors,
                "coauthorships_created": handler.coauthorship_count,
                "duration_seconds": duration
            }
            
            logger.info("DBLP parsing completed in %.2f seconds", duration)
            logger.info("Statistics: %s", stats)
            
            # Record the update in the database
            self._record_update_log(stats)
            
            return stats
            
        except Exception as e:
            logger.error("Error parsing DBLP XML: %s", str(e))
            return {"error": str(e)}
    
    def parse_by_year(self, year: str) -> Dict[str, Any]:
        """
        Parse only publications from a specific year.
        
        Args:
            year: Year to filter publications
            
        Returns:
            Dictionary with statistics about processed data
        """
        if not os.path.exists(self.xml_path):
            logger.error("DBLP XML file not found at %s", self.xml_path)
            return {"error": "XML file not found"}
        
        logger.info("Starting to parse DBLP XML file for year %s", year)
        start_time = datetime.now()
        
        # Create a custom handler that will filter by year
        handler = DBLPDatabaseHandler(self.db, filter_year=year)
        
        try:
            # Create SAX parser
            parser = xml.sax.make_parser()
            parser.setContentHandler(handler)
            
            # Parse the file
            parser.parse(self.xml_path)
            
            end_time = datetime.now()
            duration = (end_time - start_time).total_seconds()
            
            # Log statistics
            stats = {
                "year": year,
                "papers_processed": handler.paper_count,
                "authors_processed": handler.author_count,
                "new_authors_created": handler.new_authors,
                "coauthorships_created": handler.coauthorship_count,
                "duration_seconds": duration
            }
            
            logger.info("DBLP parsing for year %s completed", year)
            
            # Record the update in the database
            self._record_update_log(stats)
            
            return stats
            
        except Exception as e:
            logger.error("Error parsing DBLP XML for year %s: %s", year, str(e))
            return {"error": str(e)}
    
    def extract_coauthorship_network(self) -> Dict[str, Any]:
        """
        Extract and update the coauthorship network from the stored papers.
        
        This method processes papers in the database to build or update
        the coauthorship relationship table for conflict detection.
        
        Returns:
            Dictionary with statistics about extracted relationships
        """
        logger.info("Extracting coauthorship network from stored papers")
        start_time = datetime.now()
        
        try:
            # Get all papers with multiple authors
            papers = self.db.query(Paper).filter(Paper.publication_date != None).all()
            
            coauthorship_count = 0
            
            for paper in papers:
                authors = paper.authors
                
                # Process coauthorship relationships if paper has multiple authors
                if len(authors) > 1:
                    publication_year = paper.publication_date.year
                    
                    # Create coauthorship relationships between all author pairs
                    for i in range(len(authors)):
                        for j in range(i+1, len(authors)):
                            coauthorship_count += self._update_coauthorship(
                                authors[i].id, 
                                authors[j].id, 
                                publication_year
                            )
            
            end_time = datetime.now()
            duration = (end_time - start_time).total_seconds()
            
            stats = {
                "papers_processed": len(papers),
                "coauthorships_processed": coauthorship_count,
                "duration_seconds": duration
            }
            
            logger.info("Coauthorship network extraction completed")
            
            return stats
            
        except Exception as e:
            logger.error("Error extracting coauthorship network: %s", str(e))
            return {"error": str(e)}
    
    def _update_coauthorship(self, author1_id: int, author2_id: int, publication_year: int) -> int:
        """
        Update or create a coauthorship relationship between two authors.
        
        Args:
            author1_id: ID of first author
            author2_id: ID of second author
            publication_year: Year of the publication
            
        Returns:
            1 if a new relationship was created, 0 if updated
        """
        # Ensure consistent ordering of author IDs
        if author1_id > author2_id:
            author1_id, author2_id = author2_id, author1_id
        
        # Check if relationship already exists
        relationship = self.db.query(coauthorship).filter(
            coauthorship.c.author1_id == author1_id,
            coauthorship.c.author2_id == author2_id
        ).first()
        
        publication_date = datetime(publication_year, 1, 1)
        
        if relationship:
            # Update existing relationship
            stmt = coauthorship.update().where(
                and_(
                    coauthorship.c.author1_id == author1_id,
                    coauthorship.c.author2_id == author2_id
                )
            ).values(
                last_collaboration=max(publication_date, relationship.last_collaboration or publication_date),
                first_collaboration=min(publication_date, relationship.first_collaboration or publication_date),
                paper_count=relationship.paper_count + 1
            )
            self.db.execute(stmt)
            return 0
        else:
            # Create new relationship
            stmt = coauthorship.insert().values(
                author1_id=author1_id,
                author2_id=author2_id,
                paper_count=1,
                first_collaboration=publication_date,
                last_collaboration=publication_date
            )
            self.db.execute(stmt)
            return 1
    
    def _record_update_log(self, stats: Dict[str, Any]) -> None:
        """Record DBLP update statistics in the database."""
        log_entry = DBLPUpdateLog(
            update_date=datetime.now(),
            file_size=os.path.getsize(self.xml_path) if os.path.exists(self.xml_path) else 0,
            processed_papers=stats.get("papers_processed", 0),
            processed_authors=stats.get("authors_processed", 0),
            new_coauthorships=stats.get("coauthorships_created", 0),
            status="completed" if "error" not in stats else "failed",
            error_message=stats.get("error", None)
        )
        
        self.db.add(log_entry)
        self.db.commit()


class DBLPDatabaseHandler(DBLPHandler):
    """SAX handler that stores DBLP data directly to the database."""
    
    def __init__(self, db: Session, limit: Optional[int] = None, filter_year: Optional[str] = None):
        """
        Initialize the database handler.
        
        Args:
            db: Database session
            limit: Optional limit on records to process
            filter_year: Optional year to filter publications
        """
        super().__init__()
        self.db = db
        self.limit = limit
        self.filter_year = filter_year
        self.new_authors = 0
        self.coauthorship_count = 0
        
        # Cache to minimize database lookups
        self.author_cache = {}  # name -> Author object
    
    def process_publication(self, publication):
        """Process a publication record and store in database."""
        # Skip if limit reached
        if self.limit and self.paper_count >= self.limit:
            return
        
        # Skip if not matching filter year
        if self.filter_year and publication.get('year') != self.filter_year:
            return
        
        # Process only if we have all required data
        if 'key' in publication and 'title' in publication and 'year' in publication and publication['authors']:
            try:
                # Create or get authors
                author_objects = []
                for author_name in publication['authors']:
                    author = self._get_or_create_author(author_name)
                    if author:
                        author_objects.append(author)
                
                # Skip if no valid authors
                if not author_objects:
                    return
                
                # Create paper record
                paper = Paper(
                    title=publication.get('title', ''),
                    dblp_key=publication.get('key', ''),
                    publication_date=self._parse_date(publication.get('year')),
                    authors=author_objects
                )
                
                # Add optional fields if available
                if 'journal' in publication:
                    paper.journal = publication['journal']
                if 'booktitle' in publication:
                    paper.booktitle = publication['booktitle']
                
                self.db.add(paper)
                
                # Commit periodically to avoid memory issues
                if self.paper_count % 1000 == 0:
                    self.db.commit()
                    # Clear SQLAlchemy's identity map to reduce memory usage
                    self.db.expire_all()
                
                # Count coauthorships for statistics
                if len(author_objects) > 1:
                    self.coauthorship_count += len(author_objects) * (len(author_objects) - 1) // 2
            
            except Exception as e:
                logger.error("Error processing publication %s: %s", publication.get('key', ''), str(e))
    
    def _get_or_create_author(self, name: str) -> Optional[Author]:
        """Get existing author or create a new one."""
        # Check cache first
        if name in self.author_cache:
            return self.author_cache[name]
        
        # Check database
        author = self.db.query(Author).filter(Author.name == name).first()
        
        if not author:
            # Create new author
            author = Author(
                name=name,
                created_at=datetime.now()
            )
            self.db.add(author)
            self.db.flush()  # To get the ID assigned
            self.new_authors += 1
        
        # Add to cache
        self.author_cache[name] = author
        return author
    
    def _parse_date(self, year_str: Optional[str]) -> datetime:
        """Parse year string into datetime object."""
        if not year_str:
            return datetime.now()
        
        try:
            year = int(year_str)
            return datetime(year, 1, 1)
        except ValueError:
            return datetime.now()
