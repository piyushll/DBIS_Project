from sqlalchemy import Boolean, Column, DateTime, ForeignKey, Integer, String, Table, Text, Float
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
import datetime

Base = declarative_base()

# Association tables for many-to-many relationships
paper_author = Table(
    "paper_author",
    Base.metadata,
    Column("paper_id", Integer, ForeignKey("papers.id")),
    Column("author_id", Integer, ForeignKey("authors.id"))
)

paper_reviewer = Table(
    "paper_reviewer",
    Base.metadata,
    Column("paper_id", Integer, ForeignKey("papers.id")),
    Column("reviewer_id", Integer, ForeignKey("reviewers.id"))
)

user_role = Table(
    "user_role",
    Base.metadata,
    Column("user_id", Integer, ForeignKey("users.id")),
    Column("role_id", Integer, ForeignKey("user_roles.id"))
)

# Coauthorship tracking table (for efficient conflict detection)
coauthorship = Table(
    "coauthorship",
    Base.metadata,
    Column("author1_id", Integer, ForeignKey("authors.id"), primary_key=True),
    Column("author2_id", Integer, ForeignKey("authors.id"), primary_key=True),
    Column("paper_count", Integer, default=0),
    Column("last_collaboration", DateTime, nullable=True),
    Column("first_collaboration", DateTime, nullable=True)
)

class User(Base):
    __tablename__ = "users"
    
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(50), unique=True, index=True)
    email = Column(String(100), unique=True, index=True)
    hashed_password = Column(String(100))
    full_name = Column(String(100), nullable=True)
    affiliation = Column(String(200), nullable=True)
    country = Column(String(100), nullable=True)
    city = Column(String(100), nullable=True)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=func.now())
    
    # Relationships
    roles = relationship("UserRole", secondary=user_role, back_populates="users")
    author_profile = relationship("Author", back_populates="user", uselist=False)
    reviewer_profile = relationship("Reviewer", back_populates="user", uselist=False)

class UserRole(Base):
    __tablename__ = "user_roles"
    
    id = Column(Integer, primary_key=True, index=True)
    role_name = Column(String(50), unique=True, index=True)
    description = Column(String(200), nullable=True)
    
    # Relationships
    users = relationship("User", secondary=user_role, back_populates="roles")

class Author(Base):
    __tablename__ = "authors"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    name = Column(String(100))
    dblp_id = Column(String(100), nullable=True, unique=True, index=True)
    orcid = Column(String(50), nullable=True, unique=True, index=True)
    affiliation = Column(String(200), nullable=True)
    country = Column(String(100), nullable=True)
    city = Column(String(100), nullable=True)
    previous_affiliations = Column(Text, nullable=True)  # JSON formatted list of past affiliations with dates
    created_at = Column(DateTime, default=func.now())
    
    # Relationships
    user = relationship("User", back_populates="author_profile")
    papers = relationship("Paper", secondary=paper_author, back_populates="authors")
    
    # Self-referential relationship for coauthors
    coauthors = relationship(
        "Author",
        secondary=coauthorship,
        primaryjoin=(id == coauthorship.c.author1_id),
        secondaryjoin=(id == coauthorship.c.author2_id),
        backref="coauthored_with"
    )

class Reviewer(Base):
    __tablename__ = "reviewers"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    expertise_keywords = Column(Text)
    max_papers = Column(Integer, default=5)
    availability = Column(Boolean, default=True)
    created_at = Column(DateTime, default=func.now())
    
    # Relationships
    user = relationship("User", back_populates="reviewer_profile")
    assigned_papers = relationship("Paper", secondary=paper_reviewer, back_populates="reviewers")
    reviews = relationship("Review", back_populates="reviewer")

class Paper(Base):
    __tablename__ = "papers"
    
    id = Column(Integer, primary_key=True, index=True)
    title = Column(String(200))
    abstract = Column(Text)
    keywords = Column(String(200))
    file_path = Column(String(200))
    submission_date = Column(DateTime, default=func.now())
    publication_date = Column(DateTime, nullable=True)
    status = Column(String(50), default="Submitted")
    dblp_key = Column(String(200), nullable=True, unique=True)
    
    # Relationships
    authors = relationship("Author", secondary=paper_author, back_populates="papers")
    reviewers = relationship("Reviewer", secondary=paper_reviewer, back_populates="assigned_papers")
    reviews = relationship("Review", back_populates="paper")

class Review(Base):
    __tablename__ = "reviews"
    
    id = Column(Integer, primary_key=True, index=True)
    paper_id = Column(Integer, ForeignKey("papers.id"))
    reviewer_id = Column(Integer, ForeignKey("reviewers.id"))
    score = Column(Float, nullable=True)
    comments = Column(Text, nullable=True)
    confidentiality = Column(Integer, nullable=True)  # 1-5 scale of reviewer's confidence
    assigned_date = Column(DateTime, default=func.now())
    submitted_date = Column(DateTime, nullable=True)
    
    # Relationships
    paper = relationship("Paper", back_populates="reviews")
    reviewer = relationship("Reviewer", back_populates="reviews")

class ReviewerAssignment(Base):
    __tablename__ = "reviewer_assignments"
    
    id = Column(Integer, primary_key=True, index=True)
    paper_id = Column(Integer, ForeignKey("papers.id"))
    reviewer_id = Column(Integer, ForeignKey("reviewers.id"))
    assigned_date = Column(DateTime, default=func.now())
    status = Column(String(50), default="Assigned")  # Assigned, Accepted, Declined, Completed
    
    # Diversity metrics captured at assignment time
    diversity_score = Column(Float, nullable=True)
    conflict_free = Column(Boolean, default=True)
    
    # Relationships
    paper = relationship("Paper")
    reviewer = relationship("Reviewer")

class ConflictRecord(Base):
    __tablename__ = "conflict_records"
    
    id = Column(Integer, primary_key=True, index=True)
    author1_id = Column(Integer, ForeignKey("authors.id"))
    author2_id = Column(Integer, ForeignKey("authors.id"))
    conflict_type = Column(String(50))  # coauthorship, organization, location
    details = Column(Text, nullable=True)
    detected_date = Column(DateTime, default=func.now())
    
    # Relationships
    author1 = relationship("Author", foreign_keys=[author1_id])
    author2 = relationship("Author", foreign_keys=[author2_id])

class DBLPUpdateLog(Base):
    __tablename__ = "dblp_update_logs"
    
    id = Column(Integer, primary_key=True, index=True)
    update_date = Column(DateTime, default=func.now())
    file_size = Column(Integer)
    processed_papers = Column(Integer)
    processed_authors = Column(Integer)
    new_coauthorships = Column(Integer)
    status = Column(String(50))
    error_message = Column(Text, nullable=True)
