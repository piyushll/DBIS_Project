from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

from app.core.config import settings

# Create SQLAlchemy engine
engine = create_engine(
    settings.DATABASE_URI,
    pool_pre_ping=True,  # Test connections before using them
    pool_size=10,        # Maximum number of database connections in the pool
    max_overflow=20,     # Maximum number of connections that can be created beyond pool_size
    pool_recycle=3600,   # Recycle connections after 1 hour
    echo=False           # Set to True to log all SQL queries (useful for debugging)
)

# Create SessionLocal class with sessionmaker factory
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Base class for models
Base = declarative_base()

# Dependency to get DB session
def get_db():
    """
    Dependency function that yields a SQLAlchemy database session.
    
    This function creates a new database session for each request 
    and closes it when the request is finished, regardless of 
    whether an exception occurred.
    
    Usage:
        @router.get("/endpoint")
        def endpoint(db: Session = Depends(get_db)):
            # Use db session here
    """
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def init_db():
    """
    Initialize the database by creating all tables.
    
    This function should be called when the application starts
    to ensure all tables defined in the models exist in the database.
    """
    from app.db.models import Base
    
    # Create tables if they don't exist
    Base.metadata.create_all(bind=engine)
    
    # Initialize default roles and other required data
    db = SessionLocal()
    try:
        from app.db.models import UserRole
        
        # Check if roles already exist
        admin_role = db.query(UserRole).filter(UserRole.role_name == "admin").first()
        if not admin_role:
            # Create default roles
            roles = [
                UserRole(role_name="admin", description="System administrator"),
                UserRole(role_name="chair", description="Conference chair"),
                UserRole(role_name="reviewer", description="Paper reviewer"),
                UserRole(role_name="author", description="Paper author")
            ]
            db.add_all(roles)
            db.commit()
    finally:
        db.close()
