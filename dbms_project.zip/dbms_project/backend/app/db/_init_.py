"""
Database package for the Conference Management System.

This package contains the database models, connection management,
and session utilities for database interactions. It provides the foundation
for storing and retrieving data related to papers, authors, reviewers,
and conflict of interest information.
"""

__version__ = "0.1.0"

# Import key components for easier access from other modules
from app.db.session import SessionLocal, engine, get_db
from app.db.models import (
    Base,
    User,
    UserRole,
    Author,
    Reviewer,
    Paper,
    Review,
    ReviewerAssignment,
    paper_author,
    paper_reviewer,
    user_role
)

# Export these items as part of the public API of the db package
__all__ = [
    "Base",
    "SessionLocal",
    "engine",
    "get_db",
    "User",
    "UserRole",
    "Author",
    "Reviewer",
    "Paper",
    "Review",
    "ReviewerAssignment",
    "paper_author",
    "paper_reviewer",
    "user_role"
]
