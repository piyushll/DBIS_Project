from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import datetime, timedelta
from app.db.session import get_db
from app.db.models import Author, Paper, Reviewer, User
from app.core.security import get_current_active_user

router = APIRouter()

@router.get("/conflicts/coauthorship/{author_id}")
def detect_coauthorship_conflicts(
    author_id: int,
    years: int = 5,
    db: Session = Depends(get_db)
):
    """Detect coauthorship conflicts for an author within a given time window"""
    author = db.query(Author).filter(Author.id == author_id).first()
    if not author:
        raise HTTPException(status_code=404, detail="Author not found")

    # Find papers authored within the time window
    recent_papers = db.query(Paper).filter(
        Paper.authors.any(Author.id == author_id),
        Paper.publication_date >= datetime.now() - timedelta(days=years * 365)
    ).all()

    # Extract coauthors
    coauthors = set()
    for paper in recent_papers:
        for coauthor in paper.authors:
            if coauthor.id != author_id:
                coauthors.add(coauthor)

    return {"coauthors": [{"id": a.id, "name": a.name, "affiliation": a.affiliation} for a in coauthors]}

@router.get("/conflicts/organization/{author_id}")
def detect_organization_conflicts(
    author_id: int,
    db: Session = Depends(get_db)
):
    """Detect organization-based conflicts for an author"""
    author = db.query(Author).filter(Author.id == author_id).first()
    if not author:
        raise HTTPException(status_code=404, detail="Author not found")

    # Find authors in the same organization
    if not author.affiliation:
        return {"conflicts": []}

    conflicted_authors = db.query(Author).filter(
        Author.affiliation == author.affiliation,
        Author.id != author_id
    ).all()

    return {"conflicts": [{"id": a.id, "name": a.name, "affiliation": a.affiliation} for a in conflicted_authors]}

@router.get("/conflicts/location/{author_id}")
def detect_location_conflicts(
    author_id: int,
    db: Session = Depends(get_db)
):
    """Detect location-based conflicts for an author"""
    author = db.query(Author).filter(Author.id == author_id).first()
    if not author:
        raise HTTPException(status_code=404, detail="Author not found")

    # Find authors in the same city
    if not author.city:
        return {"conflicts": []}

    conflicted_authors = db.query(Author).filter(
        Author.city == author.city,
        Author.id != author_id
    ).all()

    return {"conflicts": [{"id": a.id, "name": a.name, "city": a.city} for a in conflicted_authors]}

@router.get("/conflicts/comprehensive/{author_id}")
def detect_all_conflicts(
    author_id: int,
    years: int = 5,
    db: Session = Depends(get_db)
):
    """Detect all types of conflicts for an author"""
    author = db.query(Author).filter(Author.id == author_id).first()
    if not author:
        raise HTTPException(status_code=404, detail="Author not found")
    
    # Coauthorship conflicts
    coauthor_results = detect_coauthorship_conflicts(author_id, years, db)
    coauthor_ids = [author["id"] for author in coauthor_results["coauthors"]]
    
    # Organization conflicts
    org_results = detect_organization_conflicts(author_id, db)
    org_ids = [author["id"] for author in org_results["conflicts"]]
    
    # Location conflicts
    loc_results = detect_location_conflicts(author_id, db)
    loc_ids = [author["id"] for author in loc_results["conflicts"]]
    
    # Combine all conflicts
    all_conflict_ids = set(coauthor_ids + org_ids + loc_ids)
    all_conflicted_authors = db.query(Author).filter(Author.id.in_(all_conflict_ids)).all()
    
    return {
        "conflicts": [
            {
                "id": a.id, 
                "name": a.name,
                "affiliation": a.affiliation,
                "city": a.city,
                "conflict_types": [
                    conflict_type for conflict_type, ids in [
                        ("coauthorship", coauthor_ids),
                        ("organization", org_ids),
                        ("location", loc_ids)
                    ] if a.id in ids
                ]
            } for a in all_conflicted_authors
        ]
    }

@router.get("/conflicts/check")
def check_conflicts_between_authors(
    author_id: int,
    potential_reviewer_id: int,
    years: int = 5,
    db: Session = Depends(get_db)
):
    """Check if there are conflicts between an author and a potential reviewer"""
    author = db.query(Author).filter(Author.id == author_id).first()
    potential_reviewer = db.query(Author).filter(Author.id == potential_reviewer_id).first()
    
    if not author or not potential_reviewer:
        raise HTTPException(status_code=404, detail="Author not found")
    
    conflicts = []
    
    # Coauthorship check
    recent_papers = db.query(Paper).filter(
        Paper.authors.any(Author.id == author_id),
        Paper.authors.any(Author.id == potential_reviewer_id),
        Paper.publication_date >= datetime.now() - timedelta(days=years * 365)
    ).all()
    
    if recent_papers:
        conflicts.append({
            "type": "coauthorship",
            "details": f"Coauthored {len(recent_papers)} papers in the last {years} years",
            "papers": [{"id": p.id, "title": p.title, "year": p.publication_date.year} for p in recent_papers]
        })
    
    # Organization check
    if author.affiliation and potential_reviewer.affiliation and author.affiliation == potential_reviewer.affiliation:
        conflicts.append({
            "type": "organization",
            "details": f"Same affiliation: {author.affiliation}"
        })
    
    # Location check
    if author.city and potential_reviewer.city and author.city == potential_reviewer.city:
        conflicts.append({
            "type": "location",
            "details": f"Same location: {author.city}"
        })
    
    return {
        "author": {"id": author.id, "name": author.name},
        "potential_reviewer": {"id": potential_reviewer.id, "name": potential_reviewer.name},
        "has_conflicts": len(conflicts) > 0,
        "conflicts": conflicts
    }

@router.get("/conflicts/paper/{paper_id}/eligible_reviewers")
def get_eligible_reviewers(
    paper_id: int,
    years: int = 5,
    db: Session = Depends(get_db)
):
    """Get eligible reviewers for a paper that have no conflicts"""
    paper = db.query(Paper).filter(Paper.id == paper_id).first()
    if not paper:
        raise HTTPException(status_code=404, detail="Paper not found")
    
    # Get all active reviewers
    reviewers = db.query(Reviewer).join(User).filter(User.is_active == True).all()
    
    # Get all author IDs for the paper
    paper_author_ids = [author.id for author in paper.authors]
    
    eligible_reviewers = []
    ineligible_reviewers = []
    
    for reviewer in reviewers:
        # Skip if reviewer is an author of the paper
        reviewer_author = db.query(Author).filter(Author.user_id == reviewer.user_id).first()
        if not reviewer_author:
            continue
            
        if reviewer_author.id in paper_author_ids:
            ineligible_reviewers.append({
                "id": reviewer.id,
                "name": reviewer.user.username,
                "conflict_reason": "Paper author"
            })
            continue
        
        # Check for conflicts
        has_conflict = False
        conflict_reasons = []
        
        for author_id in paper_author_ids:
            conflict_check = check_conflicts_between_authors(author_id, reviewer_author.id, years, db)
            if conflict_check["has_conflicts"]:
                has_conflict = True
                for conflict in conflict_check["conflicts"]:
                    conflict_reasons.append(f"{conflict['type']} with {conflict_check['author']['name']}")
        
        if has_conflict:
            ineligible_reviewers.append({
                "id": reviewer.id,
                "name": reviewer.user.username,
                "conflict_reason": ", ".join(conflict_reasons)
            })
        else:
            eligible_reviewers.append({
                "id": reviewer.id,
                "name": reviewer.user.username,
                "affiliation": reviewer_author.affiliation,
                "city": reviewer_author.city,
                "expertise_keywords": reviewer.expertise_keywords
            })
    
    return {
        "paper_id": paper_id,
        "paper_title": paper.title,
        "eligible_reviewers": eligible_reviewers,
        "ineligible_reviewers": ineligible_reviewers
    }
