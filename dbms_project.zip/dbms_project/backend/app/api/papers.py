from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form
from sqlalchemy.orm import Session
from typing import List, Optional
from app.db.session import get_db
from app.db.models import Paper, Author, Review
from app.services.reviewer_assigner import ReviewerAssigner
import datetime
import os
import uuid

router = APIRouter()

@router.post("/papers/")
async def create_paper(
    title: str = Form(...),
    abstract: str = Form(...),
    keywords: str = Form(...),
    author_ids: List[int] = Form(...),
    file: UploadFile = File(...),
    db: Session = Depends(get_db)
):
    """Create a new paper submission"""
    # Validate authors
    authors = db.query(Author).filter(Author.id.in_(author_ids)).all()
    if len(authors) != len(author_ids):
        raise HTTPException(status_code=400, detail="One or more authors not found")
    
    # Save file
    file_ext = os.path.splitext(file.filename)[1]
    file_name = f"{uuid.uuid4()}{file_ext}"
    file_path = f"uploads/papers/{file_name}"
    
    os.makedirs(os.path.dirname(file_path), exist_ok=True)
    
    with open(file_path, "wb") as buffer:
        buffer.write(await file.read())
    
    # Create paper
    paper = Paper(
        title=title,
        abstract=abstract,
        keywords=keywords,
        file_path=file_path,
        authors=authors
    )
    
    db.add(paper)
    db.commit()
    db.refresh(paper)
    
    return {"id": paper.id, "title": paper.title, "status": paper.status}

@router.get("/papers/{paper_id}")
def get_paper(paper_id: int, db: Session = Depends(get_db)):
    """Get paper details"""
    paper = db.query(Paper).filter(Paper.id == paper_id).first()
    if not paper:
        raise HTTPException(status_code=404, detail="Paper not found")
    
    return {
        "id": paper.id,
        "title": paper.title,
        "abstract": paper.abstract,
        "keywords": paper.keywords,
        "submission_date": paper.submission_date,
        "status": paper.status,
        "authors": [{"id": a.id, "name": a.name} for a in paper.authors],
        "reviewers": [{"id": r.id, "name": r.user.username} for r in paper.reviewers],
        "reviews": [
            {
                "id": r.id,
                "reviewer": r.reviewer.user.username,
                "score": r.score,
                "submitted": r.submitted_date is not None
            } for r in paper.reviews
        ]
    }

@router.get("/papers/")
def list_papers(
    status: Optional[str] = None,
    db: Session = Depends(get_db)
):
    """List papers with optional filtering"""
    query = db.query(Paper)
    
    if status:
        query = query.filter(Paper.status == status)
    
    papers = query.all()
    
    return [
        {
            "id": p.id,
            "title": p.title,
            "submission_date": p.submission_date,
            "status": p.status,
            "authors": [a.name for a in p.authors],
            "review_count": len(p.reviews)
        } for p in papers
    ]

@router.post("/papers/{paper_id}/assign_reviewers")
def assign_reviewers(
    paper_id: int,
    num_reviewers: int = 3,
    ensure_diversity: bool = True,
    db: Session = Depends(get_db)
):
    """Assign reviewers to a paper"""
    paper = db.query(Paper).filter(Paper.id == paper_id).first()
    if not paper:
        raise HTTPException(status_code=404, detail="Paper not found")
    
    # Check if paper already has reviewers
    if paper.reviewers:
        raise HTTPException(status_code=400, detail="Paper already has reviewers assigned")
    
    # Assign reviewers
    assigner = ReviewerAssigner(db)
    reviewer_ids = assigner.assign_reviewers(
        paper_id, 
        num_reviewers=num_reviewers,
        ensure_diversity=ensure_diversity
    )
    
    if len(reviewer_ids) < num_reviewers:
        raise HTTPException(status_code=400, detail="Not enough eligible reviewers available")
    
    # Get reviewer objects
    reviewers = db.query(Reviewer).filter(Reviewer.id.in_(reviewer_ids)).all()
    
    # Assign to paper
    paper.reviewers = reviewers
    
    # Create review objects
    for reviewer in reviewers:
        review = Review(
            paper_id=paper.id,
            reviewer_id=reviewer.id
        )
        db.add(review)
    
    # Update paper status
    paper.status = "Under Review"
    
    db.commit()
    
    return {
        "paper_id": paper.id,
        "assigned_reviewers": [{"id": r.id, "name": r.user.username} for r in reviewers]
    }