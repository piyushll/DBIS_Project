from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import datetime, timedelta
from jose import JWTError, jwt
from pydantic import BaseModel, EmailStr

from app.db.session import get_db
from app.db.models import User, UserRole, Reviewer, Author
from app.core.security import create_access_token, get_password_hash, verify_password
from app.core.config import settings

router = APIRouter()
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/auth/token")

# Pydantic models
class Token(BaseModel):
    access_token: str
    token_type: str

class TokenData(BaseModel):
    username: Optional[str] = None
    roles: List[str] = []

class UserCreate(BaseModel):
    username: str
    email: EmailStr
    password: str
    full_name: Optional[str] = None
    affiliation: Optional[str] = None
    country: Optional[str] = None
    city: Optional[str] = None

class UserResponse(BaseModel):
    id: int
    username: str
    email: str
    full_name: Optional[str] = None
    affiliation: Optional[str] = None
    country: Optional[str] = None
    city: Optional[str] = None
    roles: List[str]
    is_active: bool

# Authentication functions
def authenticate_user(db: Session, username: str, password: str):
    user = db.query(User).filter(User.username == username).first()
    if not user or not verify_password(password, user.hashed_password):
        return False
    return user

def get_current_user(db: Session = Depends(get_db), token: str = Depends(oauth2_scheme)):
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM])
        username: str = payload.get("sub")
        if username is None:
            raise credentials_exception
        token_data = TokenData(username=username, roles=payload.get("roles", []))
    except JWTError:
        raise credentials_exception
    user = db.query(User).filter(User.username == token_data.username).first()
    if user is None:
        raise credentials_exception
    return user

def get_current_active_user(current_user: User = Depends(get_current_user)):
    if not current_user.is_active:
        raise HTTPException(status_code=400, detail="Inactive user")
    return current_user

# Endpoint to check if user has specific role
def user_has_role(required_role: str):
    def role_checker(current_user: User = Depends(get_current_active_user)):
        user_roles = [role.role_name for role in current_user.roles]
        if required_role not in user_roles:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"User does not have required role: {required_role}"
            )
        return current_user
    return role_checker

# Auth routes
@router.post("/token", response_model=Token)
async def login_for_access_token(
    form_data: OAuth2PasswordRequestForm = Depends(),
    db: Session = Depends(get_db)
):
    user = authenticate_user(db, form_data.username, form_data.password)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    roles = [role.role_name for role in user.roles]
    access_token_expires = timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": user.username, "roles": roles}, 
        expires_delta=access_token_expires
    )
    return {"access_token": access_token, "token_type": "bearer"}

@router.post("/register", response_model=UserResponse)
async def register_user(user_data: UserCreate, db: Session = Depends(get_db)):
    # Check if username already exists
    db_user = db.query(User).filter(User.username == user_data.username).first()
    if db_user:
        raise HTTPException(
            status_code=400,
            detail="Username already registered"
        )
    
    # Check if email already exists
    db_user = db.query(User).filter(User.email == user_data.email).first()
    if db_user:
        raise HTTPException(
            status_code=400,
            detail="Email already registered"
        )
    
    # Create new user
    hashed_password = get_password_hash(user_data.password)
    db_user = User(
        username=user_data.username,
        email=user_data.email,
        hashed_password=hashed_password,
        full_name=user_data.full_name,
        affiliation=user_data.affiliation,
        country=user_data.country,
        city=user_data.city,
        is_active=True
    )
    
    # Assign default author role
    author_role = db.query(UserRole).filter(UserRole.role_name == "author").first()
    if not author_role:
        author_role = UserRole(role_name="author")
        db.add(author_role)
        db.flush()
    
    db_user.roles.append(author_role)
    
    # Create author profile
    author = Author(
        user=db_user,
        name=user_data.full_name or user_data.username,
        affiliation=user_data.affiliation,
        country=user_data.country,
        city=user_data.city
    )
    
    db.add(db_user)
    db.add(author)
    db.commit()
    db.refresh(db_user)
    
    return {
        "id": db_user.id,
        "username": db_user.username,
        "email": db_user.email,
        "full_name": db_user.full_name,
        "affiliation": db_user.affiliation,
        "country": db_user.country,
        "city": db_user.city,
        "roles": [role.role_name for role in db_user.roles],
        "is_active": db_user.is_active
    }

@router.get("/users/me", response_model=UserResponse)
async def read_users_me(current_user: User = Depends(get_current_active_user)):
    return {
        "id": current_user.id,
        "username": current_user.username,
        "email": current_user.email,
        "full_name": current_user.full_name,
        "affiliation": current_user.affiliation,
        "country": current_user.country,
        "city": current_user.city,
        "roles": [role.role_name for role in current_user.roles],
        "is_active": current_user.is_active
    }

@router.post("/users/{user_id}/roles/{role_name}")
async def assign_role(
    user_id: int, 
    role_name: str, 
    db: Session = Depends(get_db),
    current_user: User = Depends(user_has_role("admin"))
):
    # Verify user exists
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    # Verify role exists or create it
    role = db.query(UserRole).filter(UserRole.role_name == role_name).first()
    if not role:
        role = UserRole(role_name=role_name)
        db.add(role)
        db.flush()
    
    # Check if user already has this role
    if role in user.roles:
        raise HTTPException(status_code=400, detail=f"User already has role: {role_name}")
    
    # Assign role
    user.roles.append(role)
    
    # If assigning reviewer role, create reviewer profile if not exists
    if role_name == "reviewer" and not db.query(Reviewer).filter(Reviewer.user_id == user.id).first():
        reviewer = Reviewer(
            user_id=user.id,
            expertise_keywords="",  # Can be updated later
            max_papers=5,           # Default value
            availability=True
        )
        db.add(reviewer)
    
    db.commit()
    
    return {"status": "success", "message": f"Role {role_name} assigned to user {user.username}"}

@router.delete("/users/{user_id}/roles/{role_name}")
async def remove_role(
    user_id: int, 
    role_name: str, 
    db: Session = Depends(get_db),
    current_user: User = Depends(user_has_role("admin"))
):
    # Verify user exists
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    # Find role
    role = db.query(UserRole).filter(UserRole.role_name == role_name).first()
    if not role or role not in user.roles:
        raise HTTPException(status_code=404, detail=f"User does not have role: {role_name}")
    
    # Prevent removing last role
    if len(user.roles) <= 1:
        raise HTTPException(status_code=400, detail="Cannot remove the user's only role")
    
    # Remove role
    user.roles.remove(role)
    db.commit()
    
    return {"status": "success", "message": f"Role {role_name} removed from user {user.username}"}

@router.get("/users/", response_model=List[UserResponse])
async def list_users(
    role: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(user_has_role("admin"))
):
    """List all users with optional role filtering"""
    query = db.query(User)
    
    if role:
        role_obj = db.query(UserRole).filter(UserRole.role_name == role).first()
        if not role_obj:
            return []
        query = query.filter(User.roles.contains(role_obj))
    
    users = query.all()
    
    return [
        {
            "id": user.id,
            "username": user.username,
            "email": user.email,
            "full_name": user.full_name,
            "affiliation": user.affiliation,
            "country": user.country,
            "city": user.city,
            "roles": [role.role_name for role in user.roles],
            "is_active": user.is_active
        } for user in users
    ]
