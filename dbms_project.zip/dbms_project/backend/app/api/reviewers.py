from fastapi import APIRouter, Depends, HTTPException, status, Body
from sqlalchemy.orm import Session
from sqlalchemy.sql import func
from typing import List, Optional, Dict, Any
from pydantic import BaseModel

from app.db.session import get_db
from app.db.models import User, Reviewer, Author, Paper, Review, ReviewerAssignment
from app.core.security import get_current_active_user
from app.api.auth import user_has_role
from app.services.reviewer_assigner import ReviewerAssigner

router = APIRouter()

# Pydantic models
class ReviewerCreate(BaseModel):
    user_id: int
    expertise_keywords: str
    max_papers: int = 5
    availability: bool = True

class ReviewerUpdate(BaseModel):
    expertise_keywords: Optional[str] = None
    max_papers: Optional[int] = None
    availability: Optional[bool] = None

class ReviewerResponse(BaseModel):
    id: int
    user_id: int
    username: str
    full_name: Optional[str]
    affiliation: Optional[str]
    country: Optional[str]
    city: Optional[str]
    expertise_keywords: str
    max_papers: int
    current_assignments: int
    availability: bool

# Reviewer management endpoints
@router.post("/reviewers/", response_model=ReviewerResponse)
def create_reviewer(
    reviewer_data: ReviewerCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(user_has_role("admin"))
):
    """Create a new reviewer profile"""
    # Check if user exists
    user = db.query(User).filter(User.id == reviewer_data.user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    # Check if reviewer profile already exists
    existing = db.query(Reviewer).filter(Reviewer.user_id == reviewer_data.user_id).first()
    if existing:
        raise HTTPException(status_code=400, detail="Reviewer profile already exists for this user")
    
    # Create reviewer profile
    reviewer = Reviewer(
        user_id=reviewer_data.user_id,
        expertise_keywords=reviewer_data.expertise_keywords,
        max_papers=reviewer_data.max_papers,
        availability=reviewer_data.availability
    )
    
    db.add(reviewer)
    db.commit()
    db.refresh(reviewer)
    
    # Get current assignment count
    assignment_count = db.query(func.count(ReviewerAssignment.id)).filter(
        ReviewerAssignment.reviewer_id == reviewer.id
    ).scalar()
    
    # Find author profile for affiliation info
    author = db.query(Author).filter(Author.user_id == user.id).first()
    
    return {
        "id": reviewer.id,
        "user_id": reviewer.user_id,
        "username": user.username,
        "full_name": user.full_name,
        "affiliation": author.affiliation if author else None,
        "country": author.country if author else None,
        "city": author.city if author else None,
        "expertise_keywords": reviewer.expertise_keywords,
        "max_papers": reviewer.max_papers,
        "current_assignments": assignment_count,
        "availability": reviewer.availability
    }

@router.get("/reviewers/{reviewer_id}", response_model=ReviewerResponse)
def get_reviewer(
    reviewer_id: int,
    db: Session = Depends(get_db)
):
    """Get reviewer details"""
    reviewer = db.query(Reviewer).filter(Reviewer.id == reviewer_id).first()
    if not reviewer:
        raise HTTPException(status_code=404, detail="Reviewer not found")
    
    user = db.query(User).filter(User.id == reviewer.user_id).first()
    
    # Get current assignment count
    assignment_count = db.query(func.count(ReviewerAssignment.id)).filter(
        ReviewerAssignment.reviewer_id == reviewer.id
    ).scalar()
    
    # Find author profile for affiliation info
    author = db.query(Author).filter(Author.user_id == user.id).first()
    
    return {
        "id": reviewer.id,
        "user_id": reviewer.user_id,
        "username": user.username,
        "full_name": user.full_name,
        "affiliation": author.affiliation if author else None,
        "country": author.country if author else None,
        "city": author.city if author else None,
        "expertise_keywords": reviewer.expertise_keywords,
        "max_papers": reviewer.max_papers,
        "current_assignments": assignment_count,
        "availability": reviewer.availability
    }

@router.put("/reviewers/{reviewer_id}", response_model=ReviewerResponse)
def update_reviewer(
    reviewer_id: int,
    reviewer_data: ReviewerUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Update reviewer profile"""
    reviewer = db.query(Reviewer).filter(Reviewer.id == reviewer_id).first()
    if not reviewer:
        raise HTTPException(status_code=404, detail="Reviewer not found")
    
    # Check permissions
    if current_user.id != reviewer.user_id and "admin" not in [r.role_name for r in current_user.roles]:
        raise HTTPException(status_code=403, detail="Not authorized to update this reviewer")
    
    # Update fields if provided
    if reviewer_data.expertise_keywords is not None:
        reviewer.expertise_keywords = reviewer_data.expertise_keywords
    if reviewer_data.max_papers is not None:
        reviewer.max_papers = reviewer_data.max_papers
    if reviewer_data.availability is not None:
        reviewer.availability = reviewer_data.availability
    
    db.commit()
    db.refresh(reviewer)
    
    # Get user and author info
    user = db.query(User).filter(User.id == reviewer.user_id).first()
    author = db.query(Author).filter(Author.user_id == user.id).first()
    
    # Get current assignment count
    assignment_count = db.query(func.count(ReviewerAssignment.id)).filter(
        ReviewerAssignment.reviewer_id == reviewer.id
    ).scalar()
    
    return {
        "id": reviewer.id,
        "user_id": reviewer.user_id,
        "username": user.username,
        "full_name": user.full_name,
        "affiliation": author.affiliation if author else None,
        "country": author.country if author else None,
        "city": author.city if author else None,
        "expertise_keywords": reviewer.expertise_keywords,
        "max_papers": reviewer.max_papers,
        "current_assignments": assignment_count,
        "availability": reviewer.availability
    }

@router.get("/reviewers/", response_model=List[ReviewerResponse])
def list_reviewers(
    available_only: bool = False,
    expertise: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(user_has_role("chair"))
):
    """List all reviewers with optional filtering"""
    query = db.query(Reviewer)
    
    if available_only:
        query = query.filter(Reviewer.availability == True)
    
    if expertise:
        query = query.filter(Reviewer.expertise_keywords.ilike(f"%{expertise}%"))
    
    reviewers = query.all()
    result = []
    
    for reviewer in reviewers:
        user = db.query(User).filter(User.id == reviewer.user_id).first()
        author = db.query(Author).filter(Author.user_id == user.id).first()
        
        # Get current assignment count
        assignment_count = db.query(func.count(ReviewerAssignment.id)).filter(
            ReviewerAssignment.reviewer_id == reviewer.id
        ).scalar()
        
        result.append({
            "id": reviewer.id,
            "user_id": reviewer.user_id,
            "username": user.username,
            "full_name": user.full_name,
            "affiliation": author.affiliation if author else None,
            "country": author.country if author else None,
            "city": author.city if author else None,
            "expertise_keywords": reviewer.expertise_keywords,
            "max_papers": reviewer.max_papers,
            "current_assignments": assignment_count,
            "availability": reviewer.availability
        })
    
    return result

@router.get("/reviewers/{reviewer_id}/workload")
def get_reviewer_workload(
    reviewer_id: int,
    db: Session = Depends(get_db)
):
    """Get reviewer workload statistics"""
    reviewer = db.query(Reviewer).filter(Reviewer.id == reviewer_id).first()
    if not reviewer:
        raise HTTPException(status_code=404, detail="Reviewer not found")
    
    # Get all assignments
    assignments = db.query(ReviewerAssignment).filter(
        ReviewerAssignment.reviewer_id == reviewer_id
    ).all()
    
    # Get reviews
    reviews = db.query(Review).filter(
        Review.reviewer_id == reviewer_id
    ).all()
    
    # Calculate statistics
    completed_reviews = sum(1 for r in reviews if r.submitted_date is not None)
    pending_reviews = len(reviews) - completed_reviews
    
    # Calculate average completion time for completed reviews
    avg_days = 0
    if completed_reviews > 0:
        total_days = sum(
            (r.submitted_date - r.assigned_date).days 
            for r in reviews 
            if r.submitted_date is not None
        )
        avg_days = total_days / completed_reviews
    
    return {
        "reviewer_id": reviewer_id,
        "total_assignments": len(assignments),
        "completed_reviews": completed_reviews,
        "pending_reviews": pending_reviews,
        "average_days_to_complete": avg_days,
        "max_papers": reviewer.max_papers,
        "available_capacity": max(0, reviewer.max_papers - len(assignments))
    }

@router.get("/reviewers/diversity_analysis")
def analyze_reviewer_diversity(
    db: Session = Depends(get_db),
    current_user: User = Depends(user_has_role("chair"))
):
    """Analyze the diversity of the reviewer pool"""
    # Get all active reviewers
    reviewers = db.query(Reviewer).join(User).filter(User.is_active == True).all()
    
    # Get author profiles for each reviewer to access affiliation/location data
    reviewer_data = []
    for reviewer in reviewers:
        author = db.query(Author).filter(Author.user_id == reviewer.user_id).first()
        if author:
            reviewer_data.append({
                "id": reviewer.id,
                "affiliation": author.affiliation,
                "country": author.country,
                "city": author.city
            })
    
    # Calculate diversity metrics
    affiliations = {}
    countries = {}
    cities = {}
    
    for data in reviewer_data:
        if data["affiliation"]:
            affiliations[data["affiliation"]] = affiliations.get(data["affiliation"], 0) + 1
        if data["country"]:
            countries[data["country"]] = countries.get(data["country"], 0) + 1
        if data["city"]:
            cities[data["city"]] = cities.get(data["city"], 0) + 1
    
    # Sort by frequency
    top_affiliations = sorted(affiliations.items(), key=lambda x: x[1], reverse=True)
    top_countries = sorted(countries.items(), key=lambda x: x[1], reverse=True)
    top_cities = sorted(cities.items(), key=lambda x: x[1], reverse=True)
    
    # Calculate percentages
    total_reviewers = len(reviewer_data)
    
    return {
        "total_reviewers": total_reviewers,
        "affiliation_diversity": {
            "unique_affiliations": len(affiliations),
            "top_affiliations": [
                {"name": name, "count": count, "percentage": round(count/total_reviewers*100, 1)} 
                for name, count in top_affiliations[:5]
            ]
        },
        "geographical_diversity": {
            "unique_countries": len(countries),
            "unique_cities": len(cities),
            "top_countries": [
                {"name": name, "count": count, "percentage": round(count/total_reviewers*100, 1)} 
                for name, count in top_countries[:5]
            ],
            "top_cities": [
                {"name": name, "count": count, "percentage": round(count/total_reviewers*100, 1)} 
                for name, count in top_cities[:5]
            ]
        }
    }

@router.post("/reviewers/optimized_assignment")
def create_optimized_assignment(
    paper_ids: List[int] = Body(...),
    reviewers_per_paper: int = Body(3),
    enforce_diversity: bool = Body(True),
    conflict_years: int = Body(5),
    db: Session = Depends(get_db),
    current_user: User = Depends(user_has_role("chair"))
):
    """Create optimized reviewer assignments for multiple papers"""
    # Verify all papers exist
    papers = db.query(Paper).filter(Paper.id.in_(paper_ids)).all()
    if len(papers) != len(paper_ids):
        raise HTTPException(status_code=404, detail="One or more papers not found")
    
    # Get all available reviewers
    available_reviewers = db.query(Reviewer).filter(Reviewer.availability == True).all()
    if not available_reviewers:
        raise HTTPException(status_code=400, detail="No available reviewers found")
    
    # Initialize reviewer assigner service
    assigner = ReviewerAssigner(db, conflict_years=conflict_years)
    
    # Perform assignments
    assignments = {}
    failed_papers = []
    
    for paper_id in paper_ids:
        try:
            reviewer_ids = assigner.assign_reviewers(
                paper_id, 
                num_reviewers=reviewers_per_paper,
                ensure_diversity=enforce_diversity
            )
            
            if len(reviewer_ids) < reviewers_per_paper:
                failed_papers.append({
                    "paper_id": paper_id,
                    "reason": f"Could only assign {len(reviewer_ids)} reviewers (requested {reviewers_per_paper})"
                })
                # Still store partial assignments
                assignments[paper_id] = reviewer_ids
            else:
                assignments[paper_id] = reviewer_ids
                
                # Update paper status
                paper = db.query(Paper).filter(Paper.id == paper_id).first()
                paper.status = "Under Review"
                
                # Create reviewer assignments
                for reviewer_id in reviewer_ids:
                    assignment = ReviewerAssignment(
                        paper_id=paper_id,
                        reviewer_id=reviewer_id,
                        assigned_date=func.now()
                    )
                    db.add(assignment)
                    
                    # Create review record
                    review = Review(
                        paper_id=paper_id,
                        reviewer_id=reviewer_id,
                        assigned_date=func.now()
                    )
                    db.add(review)
                
        except Exception as e:
            failed_papers.append({
                "paper_id": paper_id,
                "reason": str(e)
            })
    
    db.commit()
    
    # Format detailed response
    successful_assignments = []
    for paper_id, reviewer_ids in assignments.items():
        paper = db.query(Paper).filter(Paper.id == paper_id).first()
        reviewers = db.query(Reviewer).filter(Reviewer.id.in_(reviewer_ids)).all()
        
        # Get author and reviewer affiliations for diversity reporting
        paper_authors = paper.authors
        author_affiliations = set(a.affiliation for a in paper_authors if a.affiliation)
        author_countries = set(a.country for a in paper_authors if a.country)
        
        reviewer_details = []
        reviewer_affiliations = set()
        reviewer_countries = set()
        
        for reviewer in reviewers:
            author = db.query(Author).filter(Author.user_id == reviewer.user_id).first()
            if author:
                reviewer_affiliations.add(author.affiliation)
                reviewer_countries.add(author.country)
            
            reviewer_details.append({
                "id": reviewer.id,
                "name": reviewer.user.username,
                "affiliation": author.affiliation if author else None,
                "country": author.country if author else None,
                "city": author.city if author else None
            })
        
        successful_assignments.append({
            "paper_id": paper_id,
            "paper_title": paper.title,
            "assigned_reviewers": reviewer_details,
            "diversity_metrics": {
                "unique_affiliations": len(reviewer_affiliations),
                "unique_countries": len(reviewer_countries),
                "no_affiliation_conflict": len(reviewer_affiliations.intersection(author_affiliations)) == 0,
                "no_country_conflict": len(reviewer_countries.intersection(author_countries)) == 0
            }
        })
    
    return {
        "successful_assignments": successful_assignments,
        "failed_assignments": failed_papers,
        "summary": {
            "total_papers": len(paper_ids),
            "successful_papers": len(successful_assignments),
            "failed_papers": len(failed_papers)
        }
    }
