from pyspark.sql import SparkSession
from pyspark.sql.functions import col, udf, explode, collect_list, array_contains
from pyspark.sql.types import BooleanType, StringType, ArrayType, StructType, StructField, IntegerType
import logging
from datetime import datetime, timedelta
from typing import List, Dict

class ConflictAnalyser:
    """
    Apache Spark-based service for detecting and analyzing conflicts of interest
    between authors and reviewers using the DBLP dataset.
    
    This class implements both syntactical analysis (explaining conflicts) and
    semantic analysis (suggesting resolutions) as described in conflict analysis
    literature.
    """
    
    def __init__(self, spark=None, dblp_path=None, conflict_years=5):
        """Initialize the conflict analyzer with Spark session and configuration."""
        self.spark = spark or SparkSession.builder \
            .appName("DBLP Conflict Analyzer") \
            .config("spark.executor.memory", "4g") \
            .getOrCreate()
        
        self.dblp_path = dblp_path
        self.conflict_years = conflict_years
        self.logger = logging.getLogger(__name__)
    
    def load_dblp_dataset(self):
        """
        Load and preprocess the DBLP dataset using Spark.
        
        Returns:
            DataFrame with parsed DBLP data
        """
        # Define schema for DBLP data
        schema = StructType([
            StructField("paper_id", StringType(), False),
            StructField("title", StringType(), True),
            StructField("authors", ArrayType(StringType()), True),
            StructField("year", IntegerType(), True),
            StructField("venue", StringType(), True),
            StructField("affiliations", ArrayType(StringType()), True)
        ])
        
        try:
            # Load DBLP data
            self.logger.info(f"Loading DBLP dataset from {self.dblp_path}")
            dblp_df = self.spark.read.json(self.dblp_path, schema=schema)
            
            # Filter for recent papers based on conflict_years
            current_year = datetime.now().year
            cutoff_year = current_year - self.conflict_years
            recent_papers = dblp_df.filter(col("year") >= cutoff_year)
            
            # Cache the DataFrame for better performance
            recent_papers.cache()
            self.logger.info(f"Loaded {recent_papers.count()} papers from last {self.conflict_years} years")
            
            return recent_papers
            
        except Exception as e:
            self.logger.error(f"Failed to load DBLP dataset: {str(e)}")
            raise
    
    def build_coauthorship_network(self, papers_df):
        """
        Build a coauthorship network from paper data.
        
        Args:
            papers_df: DataFrame containing paper information
            
        Returns:
            DataFrame with coauthorship relationships
        """
        # Explode the authors array to get author pairs
        authors_df = papers_df.select(
            col("paper_id"),
            col("year"),
            explode(col("authors")).alias("author1")
        )
        
        # Self-join to get all author pairs
        coauthor_pairs = authors_df.alias("a").join(
            authors_df.alias("b"),
            (col("a.paper_id") == col("b.paper_id")) & (col("a.author1") < col("b.author1"))
        ).select(
            col("a.author1"),
            col("b.author1").alias("author2"),
            col("a.paper_id"),
            col("a.year")
        )
        
        # Group by author pairs and collect paper IDs and years
        coauthorship_network = coauthor_pairs.groupBy("author1", "author2").agg(
            collect_list("paper_id").alias("paper_ids"),
            collect_list("year").alias("years")
        )
        
        # Add computed columns
        coauthorship_network = coauthorship_network.withColumn(
            "paper_count", 
            coauthorship_network.paper_ids.size()
        )
        
        self.logger.info(f"Built coauthorship network with {coauthorship_network.count()} relationships")
        return coauthorship_network
    
    def detect_conflicts(self, author_id, potential_reviewer_ids, papers_df=None, affiliation_data=None):
        """
        Detect conflicts between an author and potential reviewers.
        
        Args:
            author_id: ID of the paper author
            potential_reviewer_ids: List of potential reviewer IDs
            papers_df: DataFrame with paper data (loaded if None)
            affiliation_data: DataFrame with affiliation data (optional)
            
        Returns:
            DataFrame with conflict information
        """
        if papers_df is None:
            papers_df = self.load_dblp_dataset()
        
        # Build coauthorship network if not already provided
        coauthorship_df = self.build_coauthorship_network(papers_df)
        
        # Register a UDF to check for conflict based on paper count threshold
        @udf(returnType=BooleanType())
        def has_coauthorship_conflict(author1, author2, paper_count):
            return (author1 == author_id and author2 in potential_reviewer_ids) or \
                   (author2 == author_id and author1 in potential_reviewer_ids) and \
                   paper_count > 0
        
        # Apply the UDF to identify conflicts
        conflicts = coauthorship_df.withColumn(
            "has_conflict",
            has_coauthorship_conflict(col("author1"), col("author2"), col("paper_count"))
        ).filter(col("has_conflict") == True)
        
        # Perform syntactical analysis (explain why conflict exists)
        conflicts_explained = conflicts.withColumn(
            "conflict_type", 
            col("paper_count").cast(StringType())
        ).withColumn(
            "explanation",
            col("paper_count").cast(StringType())
        )
        
        # Perform semantic analysis (suggest resolution)
        resolution_suggestions = conflicts_explained.withColumn(
            "resolution_suggestion",
            col("paper_count").cast(StringType())
        )
        
        return resolution_suggestions
    
    def generate_conflict_report(self, paper_id, author_ids, reviewer_pool, papers_df=None):
        """
        Generate a comprehensive conflict report for a paper.
        
        Args:
            paper_id: ID of the paper
            author_ids: List of author IDs for the paper
            reviewer_pool: List of potential reviewer IDs
            papers_df: DataFrame with paper data (loaded if None)
            
        Returns:
            DataFrame with conflict report
        """
        if papers_df is None:
            papers_df = self.load_dblp_dataset()
        
        all_conflicts = []
        
        for author_id in author_ids:
            # Detect conflicts for this author
            author_conflicts = self.detect_conflicts(
                author_id, 
                reviewer_pool,
                papers_df
            )
            
            all_conflicts.append(author_conflicts)
        
        # Union all conflict results
        if all_conflicts:
            combined_conflicts = all_conflicts[0]
            for df in all_conflicts[1:]:
                combined_conflicts = combined_conflicts.union(df)
            
            # Extract conflicted reviewer IDs
            conflicted_reviewer_ids = combined_conflicts.select(
                "author1", "author2"
            ).rdd.flatMap(
                lambda row: [row.author1, row.author2]
            ).distinct().collect()
            
            # Find eligible reviewers (no conflicts)
            eligible_reviewers = [r for r in reviewer_pool if r not in conflicted_reviewer_ids]
            
            return {
                "paper_id": paper_id,
                "total_conflicts": combined_conflicts.count(),
                "conflicted_reviewers": conflicted_reviewer_ids,
                "eligible_reviewers": eligible_reviewers,
                "conflicts_data": combined_conflicts
            }
        
        return {
            "paper_id": paper_id,
            "total_conflicts": 0,
            "conflicted_reviewers": [],
            "eligible_reviewers": reviewer_pool,
            "conflicts_data": None
        }
    
    def stop(self):
        """Stop the Spark session."""
        if self.spark:
            self.spark.stop()
