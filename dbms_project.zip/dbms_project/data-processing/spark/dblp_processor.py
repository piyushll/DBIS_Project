from pyspark.sql import SparkSession
from pyspark.sql.functions import col, explode, split, regexp_extract, collect_list, struct, count, max, min
from pyspark.sql.types import StructType, StructField, StringType, ArrayType, IntegerType, DateType
import logging
import os
import xml.etree.ElementTree as ET
import datetime
from typing import Dict, List, Optional

class DBLPProcessor:
    """
    Apache Spark-based processor for the DBLP XML dataset.
    
    This class is responsible for parsing and transforming the DBLP dataset,
    extracting author relationships, and generating the data needed for
    conflict-of-interest detection in the conference management system.
    """
    
    def __init__(self, spark=None, dblp_path=None):
        """Initialize the DBLP processor with Spark session and configuration."""
        self.spark = spark or SparkSession.builder \
            .appName("DBLP Processor") \
            .config("spark.executor.memory", "4g") \
            .config("spark.driver.memory", "2g") \
            .config("spark.executor.cores", "2") \
            .config("spark.sql.execution.arrow.pyspark.enabled", "true") \
            .getOrCreate()
            
        self.dblp_path = dblp_path
        self.logger = logging.getLogger(__name__)
    
    def extract_xml_to_parquet(self, output_path: str) -> bool:
        """
        Extract DBLP XML data to Parquet format for efficient processing.
        
        Args:
            output_path: Path to store the extracted Parquet files
            
        Returns:
            Boolean indicating success or failure
        """
        try:
            self.logger.info(f"Starting XML extraction from {self.dblp_path}")
            
            # Define schema for publication data
            publication_schema = StructType([
                StructField("key", StringType(), True),
                StructField("type", StringType(), True),
                StructField("title", StringType(), True),
                StructField("authors", ArrayType(StringType()), True),
                StructField("year", IntegerType(), True),
                StructField("venue", StringType(), True),
                StructField("pages", StringType(), True),
                StructField("url", StringType(), True),
                StructField("publication_date", DateType(), True)
            ])
            
            # Use Spark to read and parse XML
            dblp_df = self.spark.read \
                .format("xml") \
                .option("rowTag", "article|inproceedings|proceedings|book|incollection|phdthesis|mastersthesis") \
                .option("valueTag", "true") \
                .load(self.dblp_path)
            
            # Transform the data
            transformed_df = dblp_df.select(
                col("_KEY").alias("key"),
                col("_tag").alias("type"),
                col("title").alias("title"),
                col("author").alias("authors"),
                col("year").cast(IntegerType()).alias("year"),
                col("journal").alias("venue"),
                col("pages").alias("pages"),
                col("ee").alias("url")
            )
            
            # Add publication date
            transformed_df = transformed_df.withColumn(
                "publication_date", 
                col("year").cast(IntegerType())
            )
            
            # Save as Parquet
            transformed_df.write.mode("overwrite").parquet(output_path)
            
            self.logger.info(f"Successfully extracted DBLP data to {output_path}")
            return True
            
        except Exception as e:
            self.logger.error(f"Error extracting DBLP XML: {str(e)}")
            return False
    
    def process_coauthorship(self, publications_path: str, output_path: str) -> bool:
        """
        Process publication data to extract coauthorship relationships.
        
        Args:
            publications_path: Path to the publications Parquet files
            output_path: Path to store the coauthorship Parquet files
            
        Returns:
            Boolean indicating success or failure
        """
        try:
            self.logger.info("Processing coauthorship relationships")
            
            # Load publications
            publications_df = self.spark.read.parquet(publications_path)
            
            # Explode authors array to get author pairs
            authors_df = publications_df.select(
                col("key"),
                col("year"),
                col("publication_date"),
                explode(col("authors")).alias("author_name")
            )
            
            # Self-join to get coauthor pairs
            coauthor_pairs = authors_df.alias("a").join(
                authors_df.alias("b"),
                (col("a.key") == col("b.key")) & (col("a.author_name") < col("b.author_name"))
            ).select(
                col("a.author_name").alias("author1"),
                col("b.author_name").alias("author2"),
                col("a.key").alias("publication_key"),
                col("a.year").alias("year"),
                col("a.publication_date").alias("publication_date")
            )
            
            # Group by author pairs and aggregate statistics
            coauthorship_df = coauthor_pairs.groupBy("author1", "author2").agg(
                count("publication_key").alias("paper_count"),
                collect_list(struct(
                    "publication_key", "year", "publication_date"
                )).alias("collaborations"),
                min("publication_date").alias("first_collaboration"),
                max("publication_date").alias("last_collaboration")
            )
            
            # Save coauthorship data
            coauthorship_df.write.mode("overwrite").parquet(output_path)
            
            # Print statistics
            total_relationships = coauthorship_df.count()
            self.logger.info(f"Processed {total_relationships} coauthorship relationships")
            
            return True
            
        except Exception as e:
            self.logger.error(f"Error processing coauthorship data: {str(e)}")
            return False
    
    def extract_affiliations(self, publications_path: str, output_path: str) -> bool:
        """
        Extract author affiliations from publication data where available.
        
        Args:
            publications_path: Path to the publications Parquet files
            output_path: Path to store the affiliations Parquet files
            
        Returns:
            Boolean indicating success or failure
        """
        try:
            self.logger.info("Extracting author affiliations")
            
            # Load publications
            publications_df = self.spark.read.parquet(publications_path)
            
            # Extract affiliations where available (this is a simplified approach since
            # DBLP doesn't consistently provide affiliation data)
            affiliations_df = publications_df.select(
                col("key"),
                col("year"),
                explode(col("authors")).alias("author_name")
            )
            
            # Group by author to get publication history
            author_history_df = affiliations_df.groupBy("author_name").agg(
                count("key").alias("publication_count"),
                min("year").alias("first_publication_year"),
                max("year").alias("last_publication_year"),
                collect_list("key").alias("publication_keys")
            )
            
            # Save affiliation data
            author_history_df.write.mode("overwrite").parquet(output_path)
            
            return True
            
        except Exception as e:
            self.logger.error(f"Error extracting affiliations: {str(e)}")
            return False
    
    def generate_conflict_matrix(
        self, 
        coauthorship_path: str, 
        output_path: str, 
        years_threshold: int = 5
    ) -> bool:
        """
        Generate a conflict matrix based on coauthorship data with time window filtering.
        
        Args:
            coauthorship_path: Path to the coauthorship Parquet files
            output_path: Path to store the conflict matrix
            years_threshold: Number of years to consider for conflicts
            
        Returns:
            Boolean indicating success or failure
        """
        try:
            self.logger.info(f"Generating conflict matrix with {years_threshold} year threshold")
            
            # Load coauthorship data
            coauthorship_df = self.spark.read.parquet(coauthorship_path)
            
            # Calculate cutoff date
            current_year = datetime.datetime.now().year
            cutoff_year = current_year - years_threshold
            
            # Filter for recent collaborations
            recent_coauthorship_df = coauthorship_df.filter(
                col("last_collaboration") >= cutoff_year
            )
            
            # Create conflict matrix
            conflict_matrix_df = recent_coauthorship_df.select(
                col("author1"),
                col("author2"),
                col("paper_count"),
                col("first_collaboration"),
                col("last_collaboration"),
                (col("last_collaboration") >= cutoff_year).alias("is_recent_conflict")
            )
            
            # Save conflict matrix
            conflict_matrix_df.write.mode("overwrite").parquet(output_path)
            
            conflict_count = conflict_matrix_df.filter(col("is_recent_conflict") == True).count()
            self.logger.info(f"Generated conflict matrix with {conflict_count} potential conflicts")
            
            return True
            
        except Exception as e:
            self.logger.error(f"Error generating conflict matrix: {str(e)}")
            return False
    
    def export_to_database(
        self,
        publications_path: str,
        coauthorship_path: str,
        jdbc_url: str,
        db_properties: Dict[str, str]
    ) -> bool:
        """
        Export processed data to the PostgreSQL database.
        
        Args:
            publications_path: Path to the publications Parquet files
            coauthorship_path: Path to the coauthorship Parquet files
            jdbc_url: JDBC URL for database connection
            db_properties: Database connection properties
            
        Returns:
            Boolean indicating success or failure
        """
        try:
            self.logger.info("Exporting processed data to database")
            
            # Load publications
            publications_df = self.spark.read.parquet(publications_path)
            
            # Load coauthorship data
            coauthorship_df = self.spark.read.parquet(coauthorship_path)
            
            # Export publications to 'papers' table
            publications_df.select(
                col("key").alias("dblp_key"),
                col("title"),
                col("year"),
                col("venue"),
                col("publication_date")
            ).write.jdbc(
                url=jdbc_url,
                table="dblp_papers",
                mode="overwrite",
                properties=db_properties
            )
            
            # Export coauthorship to 'coauthorship' table
            coauthorship_df.select(
                col("author1").alias("author1_name"),
                col("author2").alias("author2_name"),
                col("paper_count"),
                col("first_collaboration"),
                col("last_collaboration")
            ).write.jdbc(
                url=jdbc_url,
                table="dblp_coauthorship",
                mode="overwrite",
                properties=db_properties
            )
            
            self.logger.info("Successfully exported data to database")
            return True
            
        except Exception as e:
            self.logger.error(f"Error exporting to database: {str(e)}")
            return False
    
    def process_full_pipeline(
        self, 
        output_base_path: str,
        jdbc_url: Optional[str] = None,
        db_properties: Optional[Dict[str, str]] = None,
        years_threshold: int = 5
    ) -> Dict[str, any]:
        """
        Run the complete DBLP processing pipeline.
        
        Args:
            output_base_path: Base path for output files
            jdbc_url: Optional JDBC URL for database export
            db_properties: Optional database properties
            years_threshold: Number of years to consider for conflicts
            
        Returns:
            Dictionary with processing statistics
        """
        start_time = datetime.datetime.now()
        
        # Create output directories
        publications_path = os.path.join(output_base_path, "publications")
        coauthorship_path = os.path.join(output_base_path, "coauthorship")
        affiliations_path = os.path.join(output_base_path, "affiliations")
        conflict_matrix_path = os.path.join(output_base_path, "conflict_matrix")
        
        # Run pipeline steps
        extract_success = self.extract_xml_to_parquet(publications_path)
        
        if not extract_success:
            return {"status": "failed", "step": "extract_xml", "error": "Failed to extract XML data"}
        
        coauthorship_success = self.process_coauthorship(publications_path, coauthorship_path)
        
        if not coauthorship_success:
            return {"status": "failed", "step": "process_coauthorship", "error": "Failed to process coauthorship data"}
        
        affiliations_success = self.extract_affiliations(publications_path, affiliations_path)
        
        if not affiliations_success:
            return {"status": "failed", "step": "extract_affiliations", "error": "Failed to extract affiliations"}
        
        conflict_matrix_success = self.generate_conflict_matrix(
            coauthorship_path, conflict_matrix_path, years_threshold
        )
        
        if not conflict_matrix_success:
            return {"status": "failed", "step": "generate_conflict_matrix", "error": "Failed to generate conflict matrix"}
        
        # Export to database if JDBC info provided
        if jdbc_url and db_properties:
            export_success = self.export_to_database(
                publications_path, coauthorship_path, jdbc_url, db_properties
            )
            
            if not export_success:
                return {"status": "failed", "step": "export_to_database", "error": "Failed to export to database"}
        
        end_time = datetime.datetime.now()
        duration = (end_time - start_time).total_seconds()
        
        return {
            "status": "success",
            "processing_time": duration,
            "output_paths": {
                "publications": publications_path,
                "coauthorship": coauthorship_path,
                "affiliations": affiliations_path,
                "conflict_matrix": conflict_matrix_path
            }
        }
    
    def stop(self):
        """Stop the Spark session."""
        if self.spark:
            self.spark.stop()
