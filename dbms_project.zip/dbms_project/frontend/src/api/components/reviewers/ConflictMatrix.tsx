import React, { useState, useEffect } from 'react';
import { 
  Paper, 
  Table, 
  TableBody, 
  TableCell, 
  TableContainer, 
  TableHead, 
  TableRow,
  Typography,
  Box,
  Tooltip,
  IconButton,
  Chip,
  CircularProgress
} from '@mui/material';
import { 
  Check as CheckIcon, 
  Close as CloseIcon,
  Warning as WarningIcon
} from '@mui/icons-material';
import { useQuery } from 'react-query';
import { getPapers, getReviewers, getConflicts } from '../../api/conflicts';

interface Reviewer {
  id: number;
  name: string;
  organization: string;
}

interface PaperInfo {
  id: number;
  title: string;
  authors: string[];
}

interface Conflict {
  paperID: number;
  reviewerID: number;
  reasons: string[];
}

const ConflictMatrix: React.FC = () => {
  const [conflictMatrix, setConflictMatrix] = useState<Map<string, string[]>>(new Map());
  
  // Fetch papers and reviewers
  const { data: papers, isLoading: loadingPapers } = useQuery<PaperInfo[]>('papers', getPapers);
  const { data: reviewers, isLoading: loadingReviewers } = useQuery<Reviewer[]>('reviewers', getReviewers);
  const { data: conflicts, isLoading: loadingConflicts } = useQuery<Conflict[]>(
    'conflicts', 
    getConflicts,
    { enabled: !!(papers && reviewers) }
  );
  
  useEffect(() => {
    if (conflicts) {
      const matrix = new Map<string, string[]>();
      
      conflicts.forEach(conflict => {
        const key = `${conflict.paperID}-${conflict.reviewerID}`;
        matrix.set(key, conflict.reasons);
      });
      
      setConflictMatrix(matrix);
    }
  }, [conflicts]);
  
  if (loadingPapers || loadingReviewers || loadingConflicts) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', mt: 4 }}>
        <CircularProgress />
      </Box>
    );
  }
  
  if (!papers || !reviewers) {
    return (
      <Typography color="error">
        Failed to load data
      </Typography>
    );
  }
  
  const getConflictChip = (reasons: string[] | undefined) => {
    if (!reasons || reasons.length === 0) {
      return (
        <Tooltip title="No conflict">
          <CheckIcon color="success" />
        </Tooltip>
      );
    }
    
    return (
      <Tooltip title={reasons.join(', ')}>
        <Box>
          <Chip 
            icon={<WarningIcon />} 
            label={reasons.length} 
            color="error" 
            size="small"
          />
        </Box>
      </Tooltip>
    );
  };

  return (
    <Paper elevation={3} sx={{ p: 2, overflow: 'hidden' }}>
      <Typography variant="h5" gutterBottom>
        Conflict of Interest Matrix
      </Typography>
      
      <TableContainer sx={{ maxHeight: 600 }}>
        <Table stickyHeader size="small">
          <TableHead>
            <TableRow>
              <TableCell sx={{ fontWeight: 'bold', minWidth: 250 }}>Paper / Reviewer</TableCell>
              {reviewers.map(reviewer => (
                <TableCell key={reviewer.id} align="center" sx={{ minWidth: 100 }}>
                  <Tooltip title={`${reviewer.name} (${reviewer.organization})`}>
                    <Typography noWrap>
                      {reviewer.name}
                    </Typography>
                  </Tooltip>
                </TableCell>
              ))}
            </TableRow>
          </TableHead>
          <TableBody>
            {papers.map(paper => (
              <TableRow key={paper.id} hover>
                <TableCell sx={{ fontWeight: 'bold' }}>
                  <Tooltip title={`Authors: ${paper.authors.join(', ')}`}>
                    <Typography noWrap>
                      {paper.title}
                    </Typography>
                  </Tooltip>
                </TableCell>
                {reviewers.map(reviewer => (
                  <TableCell key={`${paper.id}-${reviewer.id}`} align="center">
                    {getConflictChip(conflictMatrix.get(`${paper.id}-${reviewer.id}`))}
                  </TableCell>
                ))}
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </Paper>
  );
};

export default ConflictMatrix;