import React, { useState } from 'react';
import { 
  TextField, 
  Button, 
  Box, 
  Typography, 
  Paper, 
  Chip,
  Autocomplete,
  CircularProgress
} from '@mui/material';
import { useNavigate } from 'react-router-dom';
import { useQuery, useMutation } from 'react-query';
import { getAuthors, submitPaper } from '../../api/papers';

interface Author {
  id: number;
  name: string;
}

const PaperSubmission: React.FC = () => {
  const navigate = useNavigate();
  const [title, setTitle] = useState('');
  const [abstract, setAbstract] = useState('');
  const [keywords, setKeywords] = useState('');
  const [selectedAuthors, setSelectedAuthors] = useState<Author[]>([]);
  const [file, setFile] = useState<File | null>(null);
  const [fileError, setFileError] = useState('');

  // Fetch authors
  const { data: authors, isLoading: isLoadingAuthors } = useQuery('authors', getAuthors);

  // Submit paper mutation
  const { mutate, isLoading: isSubmitting } = useMutation(submitPaper, {
    onSuccess: () => {
      navigate('/papers');
    }
  });

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const selectedFile = e.target.files[0];
      
      // Validate file type (PDF only)
      if (selectedFile.type !== 'application/pdf') {
        setFileError('Only PDF files are accepted');
        setFile(null);
        return;
      }
      
      // Validate file size (max 10MB)
      if (selectedFile.size > 10 * 1024 * 1024) {
        setFileError('File size should not exceed 10MB');
        setFile(null);
        return;
      }
      
      setFile(selectedFile);
      setFileError('');
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!file) {
      setFileError('Please upload a PDF file');
      return;
    }
    
    const formData = new FormData();
    formData.append('title', title);
    formData.append('abstract', abstract);
    formData.append('keywords', keywords);
    selectedAuthors.forEach((author, index) => {
      formData.append(`author_ids`, author.id.toString());
    });
    formData.append('file', file);
    
    mutate(formData);
  };

  return (
    <Paper elevation={3} sx={{ p: 4, maxWidth: 800, mx: 'auto', mt: 4 }}>
      <Typography variant="h4" gutterBottom>
        Submit New Paper
      </Typography>
      
      <Box component="form" onSubmit={handleSubmit} noValidate>
        <TextField
          margin="normal"
          required
          fullWidth
          id="title"
          label="Paper Title"
          name="title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
        />
        
        <TextField
          margin="normal"
          required
          fullWidth
          id="abstract"
          label="Abstract"
          name="abstract"
          multiline
          rows={4}
          value={abstract}
          onChange={(e) => setAbstract(e.target.value)}
        />
        
        <TextField
          margin="normal"
          required
          fullWidth
          id="keywords"
          label="Keywords (comma separated)"
          name="keywords"
          value={keywords}
          onChange={(e) => setKeywords(e.target.value)}
          helperText="Example: machine learning, artificial intelligence, neural networks"
        />
        
        <Autocomplete
          multiple
          id="authors"
          options={authors || []}
          getOptionLabel={(option) => option.name}
          loading={isLoadingAuthors}
          value={selectedAuthors}
          onChange={(_, newValue) => setSelectedAuthors(newValue)}
          renderInput={(params) => (
            <TextField
              {...params}
              label="Authors"
              margin="normal"
              required
              InputProps={{
                ...params.InputProps,
                endAdornment: (
                  <>
                    {isLoadingAuthors ? <CircularProgress color="inherit" size={20} /> : null}
                    {params.InputProps.endAdornment}
                  </>
                ),
              }}
            />
          )}
          renderTags={(tagValue, getTagProps) =>
            tagValue.map((option, index) => (
              <Chip 
                label={option.name} 
                {...getTagProps({ index })} 
              />
            ))
          }
        />
        
        <Box sx={{ mt: 2 }}>
          <Button
            variant="contained"
            component="label"
            sx={{ mr: 2 }}
          >
            Upload Paper (PDF)
            <input
              type="file"
              accept=".pdf"
              hidden
              onChange={handleFileChange}
            />
          </Button>
          {file && (
            <Typography variant="body2" component="span">
              {file.name}
            </Typography>
          )}
          {fileError && (
            <Typography color="error" variant="body2">
              {fileError}
            </Typography>
          )}
        </Box>
        
        <Box sx={{ mt: 4 }}>
          <Button
            type="submit"
            variant="contained"
            color="primary"
            disabled={isSubmitting}
            sx={{ px: 4, py: 1 }}
          >
            {isSubmitting ? <CircularProgress size={24} /> : 'Submit Paper'}
          </Button>
        </Box>
      </Box>
    </Paper>
  );
};

export default PaperSubmission;