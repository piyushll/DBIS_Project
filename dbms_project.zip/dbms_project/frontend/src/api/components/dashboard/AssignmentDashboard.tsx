import React, { useState } from 'react';
import {
  Box,
  Paper,
  Typography,
  Grid,
  Card,
  CardContent,
  CardActions,
  Button,
  Chip,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  FormControlLabel,
  Checkbox,
  TextField,
  CircularProgress,
  Alert
} from '@mui/material';
import { useQuery, useMutation, useQueryClient } from 'react-query';
import { getPendingPapers, assignReviewers } from '../../api/assignments';

interface Paper {
  id: number;
  title: string;
  authors: string[];
  submissionDate: string;
}

const AssignmentDashboard: React.FC = () => {
  const queryClient = useQueryClient();
  const [selectedPaper, setSelectedPaper] = useState<Paper | null>(null);
  const [assignmentDialogOpen, setAssignmentDialogOpen] = useState(false);
  const [numReviewers, setNumReviewers] = useState(3);
  const [ensureDiversity, setEnsureDiversity] = useState(true);
  
  // Get papers pending reviewer assignment
  const { data: pendingPapers, isLoading: loadingPapers } = useQuery<Paper[]>(
    'pendingPapers',
    getPendingPapers
  );
  
  // Mutation for assigning reviewers
  const { mutate, isLoading: isAssigning, error: assignmentError } = useMutation(
    assignReviewers,
    {
      onSuccess: () => {
        setAssignmentDialogOpen(false);
        queryClient.invalidateQueries('pendingPapers');
      }
    }
  );
  
  const handleAssignReviewers = () => {
    if (selectedPaper) {
      mutate({
        paperId: selectedPaper.id,
        numReviewers,
        ensureDiversity
      });
    }
  };
  
  const openAssignmentDialog = (paper: Paper) => {
    setSelectedPaper(paper);
    setAssignmentDialogOpen(true);
  };
  
  const closeAssignmentDialog = () => {
    setAssignmentDialogOpen(false);
    setSelectedPaper(null);
  };

  return (
    <Box sx={{ p: 2 }}>
      <Typography variant="h4" gutterBottom>
        Reviewer Assignment Dashboard
      </Typography>
      
      {loadingPapers ? (
        <Box sx={{ display: 'flex', justifyContent: 'center', mt: 4 }}>
          <CircularProgress />
        </Box>
      ) : !pendingPapers || pendingPapers.length === 0 ? (
        <Alert severity="info">
          No papers currently pending reviewer assignment
        </Alert>
      ) : (
        <Grid container spacing={3} sx={{ mt: 2 }}>
          {pendingPapers.map(paper => (
            <Grid item xs={12} md={6} lg={4} key={paper.id}>
              <Card variant="outlined">
                <CardContent>
                  <Typography variant="h6" gutterBottom noWrap>
                    {paper.title}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Submitted: {new Date(paper.submissionDate).toLocaleDateString()}
                  </Typography>
                  <Box sx={{ mt: 2 }}>
                    <Typography variant="body2">Authors:</Typography>
                    <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5, mt: 1 }}>
                      {paper.authors.map((author, index) => (
                        <Chip key={index} label={author} size="small" />
                      ))}
                    </Box>
                  </Box>
                </CardContent>
                <CardActions>
                  <Button 
                    size="small" 
                    variant="contained"
                    onClick={() => openAssignmentDialog(paper)}
                  >
                    Assign Reviewers
                  </Button>
                </CardActions>
              </Card>
            </Grid>
          ))}
        </Grid>
      )}
      
      <Dialog open={assignmentDialogOpen} onClose={closeAssignmentDialog}>
        <DialogTitle>
          Assign Reviewers
        </DialogTitle>
        <DialogContent>
          {selectedPaper && (
            <Box>
              <Typography variant="subtitle1" gutterBottom>
                {selectedPaper.title}
              </Typography>
              
              <TextField
                margin="normal"
                label="Number of Reviewers"
                type="number"
                value={numReviewers}
                onChange={(e) => setNumReviewers(parseInt(e.target.value) || 3)}
                fullWidth
                inputProps={{ min: 2, max: 5 }}
              />
              
              <FormControlLabel
                control={
                  <Checkbox
                    checked={ensureDiversity}
                    onChange={(e) => setEnsureDiversity(e.target.checked)}
                  />
                }
                label="Ensure organizational diversity"
              />
              
              {assignmentError && (
                <Alert severity="error" sx={{ mt: 2 }}>
                  {assignmentError instanceof Error ? assignmentError.message : 'Error assigning reviewers'}
                </Alert>
              )}
            </Box>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={closeAssignmentDialog}>Cancel</Button>
          <Button 
            onClick={handleAssignReviewers} 
            variant="contained"
            disabled={isAssigning}
          >
            {isAssigning ? <CircularProgress size={24} /> : 'Assign'}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default AssignmentDashboard;